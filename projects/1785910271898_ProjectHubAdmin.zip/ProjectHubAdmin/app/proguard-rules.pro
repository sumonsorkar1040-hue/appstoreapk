# Add project specific ProGuard rules here.
-keep class com.projecthub.admin.model.** { *; }
-keep class com.projecthub.admin.api.** { *; }
