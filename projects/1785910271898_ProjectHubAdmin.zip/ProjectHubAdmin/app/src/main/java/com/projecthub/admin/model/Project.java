package com.projecthub.admin.model;

import java.util.ArrayList;
import java.util.List;

public class Project {
    public String projectId;
    public String name;
    public String category;
    public String thumbnailUrl;
    public String bannerUrl;
    public List<String> screenshots = new ArrayList<>();
    public String demoVideoLink;
    public String livePreviewLink;
    public String description;
    public List<String> features = new ArrayList<>();
    public List<String> requirements = new ArrayList<>();
    public String installationGuide;
    public String version;
    public String fileSize;
    public long updateDate;
    public String developerName;
    public double price;
    public double discountPrice;
    public boolean couponAvailable;

    // GitHub file info (auto uploaded zip)
    public String downloadFileUrl;   // raw download URL after GitHub upload
    public String githubPath;        // path inside repo

    public boolean featured;
    public boolean trending;
    public boolean bestSeller;
    public boolean flashSale;
    public boolean visible = true;

    public double rating;
    public int reviewCount;
    public int downloadCount;
    public long createdAt;

    public Project() {
        // required empty constructor for Firebase
    }
}
