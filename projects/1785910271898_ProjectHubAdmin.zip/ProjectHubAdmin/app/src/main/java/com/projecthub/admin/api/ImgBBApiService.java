package com.projecthub.admin.api;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ImgBBApiService {

    // https://api.imgbb.com/  -> POST https://api.imgbb.com/1/upload?key=API_KEY
    @Multipart
    @POST("1/upload")
    Call<ImgBBResponse> uploadImage(
            @Query("key") String apiKey,
            @Part MultipartBody.Part image
    );
}
