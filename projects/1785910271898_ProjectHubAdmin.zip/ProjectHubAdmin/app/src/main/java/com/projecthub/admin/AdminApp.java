package com.projecthub.admin;

import android.app.Application;
import com.google.firebase.FirebaseApp;

public class AdminApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);
    }
}
