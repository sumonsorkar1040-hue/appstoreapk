package com.projecthub.admin.model;

public class Order {
    public String orderId;
    public String userId;
    public String userName;
    public String projectId;
    public String projectName;
    public String projectThumb;
    public double amount;
    public String paymentMethod;
    public String transactionId;
    public String status; // Pending, Paid, Completed, Cancelled, Refunded
    public boolean downloadPermission;
    public long orderDate;

    public Order() {
    }
}
