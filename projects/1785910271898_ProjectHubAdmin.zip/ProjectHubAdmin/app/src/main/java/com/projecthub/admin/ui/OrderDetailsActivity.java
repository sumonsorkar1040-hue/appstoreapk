package com.projecthub.admin.ui;

public class OrderDetailsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Order Details";
    }
}
