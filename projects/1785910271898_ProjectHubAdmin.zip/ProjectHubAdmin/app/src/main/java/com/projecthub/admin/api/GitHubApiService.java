package com.projecthub.admin.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface GitHubApiService {

    // PUT https://api.github.com/repos/{owner}/{repo}/contents/{path}
    // Uploads (creates) a file using the GitHub Contents API.
    // File content must be Base64 encoded (this is how GitHub's API requires it).
    @PUT("repos/{owner}/{repo}/contents/{path}")
    Call<GitHubUploadResponse> uploadFile(
            @Header("Authorization") String token, // "token ghp_xxx"
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path(value = "path", encoded = true) String path,
            @Body GitHubUploadRequest body
    );
}
