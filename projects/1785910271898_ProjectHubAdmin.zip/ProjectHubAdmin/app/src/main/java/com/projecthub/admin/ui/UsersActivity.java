package com.projecthub.admin.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.projecthub.admin.R;
import com.projecthub.admin.adapter.UserAdapter;
import com.projecthub.admin.model.AppUser;
import com.projecthub.admin.utils.FirebaseHelper;

import java.util.ArrayList;
import java.util.List;

public class UsersActivity extends AppCompatActivity {

    private final List<AppUser> allUsers = new ArrayList<>();
    private final List<AppUser> filteredUsers = new ArrayList<>();
    private UserAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        RecyclerView rv = findViewById(R.id.rvUsers);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new UserAdapter(filteredUsers);
        rv.setAdapter(adapter);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        EditText etSearch = findViewById(R.id.etSearchUser);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        loadUsers();
    }

    private void loadUsers() {
        FirebaseHelper.users().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                allUsers.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    AppUser user = child.getValue(AppUser.class);
                    if (user != null) {
                        user.uid = child.getKey();
                        allUsers.add(0, user);
                    }
                }
                filteredUsers.clear();
                filteredUsers.addAll(allUsers);
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void filter(String query) {
        filteredUsers.clear();
        String q = query.toLowerCase().trim();
        for (AppUser u : allUsers) {
            if (q.isEmpty()
                    || (u.name != null && u.name.toLowerCase().contains(q))
                    || (u.email != null && u.email.toLowerCase().contains(q))) {
                filteredUsers.add(u);
            }
        }
        adapter.notifyDataSetChanged();
    }
}
