package com.projecthub.admin.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.projecthub.admin.R;

/**
 * Lightweight placeholder screen. Extend this for any module whose full
 * CRUD UI hasn't been generated yet, so the app still compiles & navigates
 * cleanly. Swap setContentView(R.layout.activity_placeholder) for a real
 * layout when you're ready to build that module out.
 */
public abstract class BasePlaceholderActivity extends AppCompatActivity {

    protected abstract String getScreenTitle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeholder);
        TextView tvTitle = findViewById(R.id.tvTitle);
        tvTitle.setText(getScreenTitle());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}
