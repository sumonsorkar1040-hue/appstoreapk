package com.projecthub.admin.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.projecthub.admin.R;
import com.projecthub.admin.utils.FirebaseHelper;

import java.util.HashMap;
import java.util.Map;

public class SendNotificationActivity extends AppCompatActivity {

    private final String[] notifTypes = {
            "General", "New Project Alert", "Discount Alert", "Maintenance Notice", "Update Notification"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_notification);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        Spinner spinnerType = findViewById(R.id.spinnerNotifType);
        spinnerType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, notifTypes));

        RadioGroup radioGroupTarget = findViewById(R.id.radioGroupTarget);
        EditText etSpecificUserId = findViewById(R.id.etSpecificUserId);
        radioGroupTarget.setOnCheckedChangeListener((group, checkedId) ->
                etSpecificUserId.setVisibility(checkedId == R.id.radioSpecificUser ? View.VISIBLE : View.GONE));

        findViewById(R.id.btnSendNotification).setOnClickListener(v -> sendNotification());
    }

    private void sendNotification() {
        EditText etTitle = findViewById(R.id.etNotifTitle);
        EditText etMessage = findViewById(R.id.etNotifMessage);
        EditText etImage = findViewById(R.id.etNotifImage);
        EditText etSpecificUserId = findViewById(R.id.etSpecificUserId);
        RadioGroup radioGroupTarget = findViewById(R.id.radioGroupTarget);
        Spinner spinnerType = findViewById(R.id.spinnerNotifType);

        String title = etTitle.getText().toString().trim();
        String message = etMessage.getText().toString().trim();

        if (title.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Title and message are required", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isSpecific = radioGroupTarget.getCheckedRadioButtonId() == R.id.radioSpecificUser;

        Map<String, Object> notif = new HashMap<>();
        notif.put("title", title);
        notif.put("message", message);
        notif.put("imageUrl", etImage.getText().toString().trim());
        notif.put("type", spinnerType.getSelectedItem() != null ? spinnerType.getSelectedItem().toString() : "General");
        notif.put("target", isSpecific ? "specific" : "all");
        notif.put("targetUserId", isSpecific ? etSpecificUserId.getText().toString().trim() : null);
        notif.put("status", "queued"); // a Cloud Function listening on this node sends via FCM then flips to "sent"
        notif.put("createdAt", System.currentTimeMillis());

        FirebaseHelper.notifications().push().setValue(notif)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Notification queued", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}
