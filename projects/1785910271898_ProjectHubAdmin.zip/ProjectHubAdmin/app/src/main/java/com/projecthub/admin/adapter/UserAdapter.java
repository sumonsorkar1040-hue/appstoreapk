package com.projecthub.admin.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.projecthub.admin.R;
import com.projecthub.admin.model.AppUser;
import com.projecthub.admin.ui.UserDetailsActivity;
import com.projecthub.admin.utils.FirebaseHelper;

import de.hdodenhof.circleimageview.CircleImageView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private final List<AppUser> userList;

    public UserAdapter(List<AppUser> userList) {
        this.userList = userList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        AppUser user = userList.get(position);
        holder.tvUserName.setText(user.name);
        holder.tvUserEmail.setText(user.email);
        holder.tvUserSpent.setText(String.format("$%.2f", user.totalSpent));
        holder.tvUserOrders.setText(user.totalOrders + " Orders");

        if (user.blocked) {
            holder.tvUserBadge.setText("Blocked");
            holder.tvUserBadge.setTextColor(holder.itemView.getResources().getColor(R.color.danger));
        } else if (user.verified) {
            holder.tvUserBadge.setText("Verified");
            holder.tvUserBadge.setTextColor(holder.itemView.getResources().getColor(R.color.success));
        } else {
            holder.tvUserBadge.setText("Unverified");
            holder.tvUserBadge.setTextColor(holder.itemView.getResources().getColor(R.color.text_secondary));
        }

        Glide.with(holder.itemView.getContext())
                .load(user.profileImage)
                .placeholder(android.R.drawable.sym_def_app_icon)
                .into(holder.ivAvatar);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), UserDetailsActivity.class);
            intent.putExtra("userId", user.uid);
            v.getContext().startActivity(intent);
        });

        holder.itemView.setOnLongClickListener(v -> {
            showMenu(v, user);
            return true;
        });
    }

    private void showMenu(View anchor, AppUser user) {
        PopupMenu popup = new PopupMenu(anchor.getContext(), anchor);
        popup.getMenu().add(user.blocked ? "Unblock User" : "Block User");
        popup.getMenu().add(user.verified ? "Remove Verified Badge" : "Verify User");
        popup.getMenu().add("Delete User");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.contains("Block") && !title.contains("Unblock")) {
                FirebaseHelper.users().child(user.uid).child("blocked").setValue(true);
            } else if (title.contains("Unblock")) {
                FirebaseHelper.users().child(user.uid).child("blocked").setValue(false);
            } else if (title.equals("Verify User")) {
                FirebaseHelper.users().child(user.uid).child("verified").setValue(true);
            } else if (title.contains("Remove Verified")) {
                FirebaseHelper.users().child(user.uid).child("verified").setValue(false);
            } else if (title.equals("Delete User")) {
                FirebaseHelper.users().child(user.uid).removeValue();
            }
            return true;
        });
        popup.show();
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivAvatar;
        TextView tvUserName, tvUserEmail, tvUserBadge, tvUserSpent, tvUserOrders;

        UserViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.ivAvatar);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserEmail = itemView.findViewById(R.id.tvUserEmail);
            tvUserBadge = itemView.findViewById(R.id.tvUserBadge);
            tvUserSpent = itemView.findViewById(R.id.tvUserSpent);
            tvUserOrders = itemView.findViewById(R.id.tvUserOrders);
        }
    }
}
