package com.projecthub.admin.ui;

public class SettingsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Settings";
    }
}
