package com.projecthub.admin.utils;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Central place for all Firebase Realtime Database node references.
 * Database structure:
 *  /Admins/{adminUid}
 *  /Users/{userUid}
 *  /Projects/{projectId}
 *  /Categories/{categoryId}
 *  /Orders/{orderId}
 *  /Payments/{paymentId}
 *  /Reviews/{reviewId}
 *  /Coupons/{couponId}
 *  /Banners/{bannerId}
 *  /Notifications/{notifId}
 *  /Settings/AppConfig
 *  /Analytics/Summary
 */
public class FirebaseHelper {

    private static FirebaseDatabase database;

    public static FirebaseDatabase getDb() {
        if (database == null) {
            database = FirebaseDatabase.getInstance();
            database.setPersistenceEnabled(true);
        }
        return database;
    }

    public static DatabaseReference admins()       { return getDb().getReference("Admins"); }
    public static DatabaseReference users()         { return getDb().getReference("Users"); }
    public static DatabaseReference projects()      { return getDb().getReference("Projects"); }
    public static DatabaseReference categories()    { return getDb().getReference("Categories"); }
    public static DatabaseReference orders()        { return getDb().getReference("Orders"); }
    public static DatabaseReference payments()      { return getDb().getReference("Payments"); }
    public static DatabaseReference reviews()       { return getDb().getReference("Reviews"); }
    public static DatabaseReference coupons()       { return getDb().getReference("Coupons"); }
    public static DatabaseReference banners()       { return getDb().getReference("Banners"); }
    public static DatabaseReference notifications() { return getDb().getReference("Notifications"); }
    public static DatabaseReference settings()      { return getDb().getReference("Settings"); }
    public static DatabaseReference analytics()     { return getDb().getReference("Analytics"); }
    public static DatabaseReference activityLog()   { return getDb().getReference("ActivityLog"); }
}
