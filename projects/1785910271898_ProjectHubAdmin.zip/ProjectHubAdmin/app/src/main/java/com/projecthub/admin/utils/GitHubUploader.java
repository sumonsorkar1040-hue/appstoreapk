package com.projecthub.admin.utils;

import android.content.Context;
import android.net.Uri;
import android.util.Base64;

import com.projecthub.admin.BuildConfig;
import com.projecthub.admin.api.GitHubUploadRequest;
import com.projecthub.admin.api.GitHubUploadResponse;
import com.projecthub.admin.api.RetrofitClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Handles automatic .zip project file upload directly to a GitHub repository
 * using the GitHub Contents API. The returned "download_url" is a permanent
 * raw.githubusercontent.com link that can be stored in Firebase as the
 * project's Download File Link.
 *
 * Requires a GitHub Personal Access Token (classic, with "repo" scope) set in
 * BuildConfig.GITHUB_TOKEN, plus BuildConfig.GITHUB_OWNER / GITHUB_REPO.
 *
 * NOTE: GitHub Contents API works well for files up to ~25MB (single request).
 * For larger zip files, use the Git Data API (blobs) instead - ask and I will
 * add that variant.
 */
public class GitHubUploader {

    public interface UploadCallback {
        void onSuccess(String downloadUrl, String path);
        void onError(String error);
    }

    public static void uploadZip(Context context, Uri zipUri, String fileNameInRepo, UploadCallback callback) {
        try {
            byte[] fileBytes = readBytes(context, zipUri);
            String base64Content = Base64.encodeToString(fileBytes, Base64.NO_WRAP);

            String path = "projects/" + fileNameInRepo; // e.g. projects/ecommerce-script-v1.zip
            String token = "token " + BuildConfig.GITHUB_TOKEN;

            GitHubUploadRequest body = new GitHubUploadRequest(
                    "Upload project file: " + fileNameInRepo,
                    base64Content,
                    "main"
            );

            Call<GitHubUploadResponse> call = RetrofitClient.getGitHubService().uploadFile(
                    token, BuildConfig.GITHUB_OWNER, BuildConfig.GITHUB_REPO, path, body
            );

            call.enqueue(new Callback<GitHubUploadResponse>() {
                @Override
                public void onResponse(Call<GitHubUploadResponse> call, Response<GitHubUploadResponse> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().content != null) {
                        callback.onSuccess(response.body().content.downloadUrl, response.body().content.path);
                    } else {
                        callback.onError("GitHub upload failed: HTTP " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<GitHubUploadResponse> call, Throwable t) {
                    callback.onError(t.getMessage());
                }
            });
        } catch (Exception e) {
            callback.onError(e.getMessage());
        }
    }

    private static byte[] readBytes(Context context, Uri uri) throws Exception {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[8192];
        int read;
        while (inputStream != null && (read = inputStream.read(data)) != -1) {
            buffer.write(data, 0, read);
        }
        if (inputStream != null) inputStream.close();
        return buffer.toByteArray();
    }
}
