package com.projecthub.admin.utils;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class AdminFcmService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        // TODO: build a NotificationCompat here to alert the admin about
        // new orders, refund requests, low stock, etc. Kept minimal for now.
    }

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        // Optionally store this admin device's token under /Admins/{uid}/fcmToken
        // so a Cloud Function can notify this specific admin device.
    }
}
