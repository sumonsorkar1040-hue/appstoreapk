package com.projecthub.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.projecthub.admin.R;
import com.projecthub.admin.utils.FirebaseHelper;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(this::routeUser, 1200);
    }

    private void routeUser() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Verify this uid actually exists under /Admins before granting access
        String uid = auth.getCurrentUser().getUid();
        FirebaseHelper.admins().child(uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                startActivity(new Intent(this, DashboardActivity.class));
            } else {
                auth.signOut();
                startActivity(new Intent(this, LoginActivity.class));
            }
            finish();
        });
    }
}
