package com.projecthub.admin.ui;

public class ReviewsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Reviews";
    }
}
