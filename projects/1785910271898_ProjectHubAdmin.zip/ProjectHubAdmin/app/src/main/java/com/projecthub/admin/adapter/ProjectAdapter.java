package com.projecthub.admin.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.projecthub.admin.R;
import com.projecthub.admin.model.Project;
import com.projecthub.admin.ui.AddProjectActivity;
import com.projecthub.admin.ui.ProjectDetailsActivity;
import com.projecthub.admin.utils.FirebaseHelper;

import java.util.List;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ProjectViewHolder> {

    private final List<Project> projectList;

    public ProjectAdapter(List<Project> projectList) {
        this.projectList = projectList;
    }

    @NonNull
    @Override
    public ProjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_project, parent, false);
        return new ProjectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectViewHolder holder, int position) {
        Project project = projectList.get(position);
        holder.tvName.setText(project.name);
        holder.tvPrice.setText(String.format("$%.2f", project.price));
        holder.tvStatus.setText(project.visible ? "Published" : "Hidden");
        holder.tvStatus.setTextColor(holder.itemView.getResources()
                .getColor(project.visible ? R.color.success : R.color.danger));

        Glide.with(holder.itemView.getContext())
                .load(project.thumbnailUrl)
                .placeholder(R.drawable.bg_card_rounded)
                .into(holder.ivThumb);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), ProjectDetailsActivity.class);
            intent.putExtra("projectId", project.projectId);
            v.getContext().startActivity(intent);
        });

        holder.btnMenu.setOnClickListener(v -> showMenu(v, project));
    }

    private void showMenu(View anchor, Project project) {
        PopupMenu popup = new PopupMenu(anchor.getContext(), anchor);
        popup.getMenu().add("Edit");
        popup.getMenu().add(project.visible ? "Hide" : "Show");
        popup.getMenu().add("Delete");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            switch (title) {
                case "Edit":
                    Intent intent = new Intent(anchor.getContext(), AddProjectActivity.class);
                    intent.putExtra("projectId", project.projectId);
                    anchor.getContext().startActivity(intent);
                    return true;
                case "Hide":
                case "Show":
                    FirebaseHelper.projects().child(project.projectId)
                            .child("visible").setValue(!project.visible);
                    return true;
                case "Delete":
                    FirebaseHelper.projects().child(project.projectId).removeValue();
                    return true;
            }
            return false;
        });
        popup.show();
    }

    @Override
    public int getItemCount() {
        return projectList.size();
    }

    static class ProjectViewHolder extends RecyclerView.ViewHolder {
        ImageView ivThumb;
        TextView tvName, tvPrice, tvStatus;
        android.widget.ImageButton btnMenu;

        ProjectViewHolder(@NonNull View itemView) {
            super(itemView);
            ivThumb = itemView.findViewById(R.id.ivThumb);
            tvName = itemView.findViewById(R.id.tvName);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnMenu = itemView.findViewById(R.id.btnMenu);
        }
    }
}
