package com.projecthub.admin.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.projecthub.admin.R;
import com.projecthub.admin.adapter.ProjectAdapter;
import com.projecthub.admin.model.Project;
import com.projecthub.admin.utils.FirebaseHelper;

import java.util.ArrayList;
import java.util.List;

public class ProjectsActivity extends AppCompatActivity {

    private final List<Project> projectList = new ArrayList<>();
    private ProjectAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projects);

        RecyclerView rv = findViewById(R.id.rvProjects);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProjectAdapter(projectList);
        rv.setAdapter(adapter);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAddProject).setOnClickListener(v ->
                startActivity(new Intent(this, AddProjectActivity.class)));

        loadProjects();
    }

    private void loadProjects() {
        FirebaseHelper.projects().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                projectList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Project p = child.getValue(Project.class);
                    if (p != null) {
                        p.projectId = child.getKey();
                        projectList.add(0, p);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }
}
