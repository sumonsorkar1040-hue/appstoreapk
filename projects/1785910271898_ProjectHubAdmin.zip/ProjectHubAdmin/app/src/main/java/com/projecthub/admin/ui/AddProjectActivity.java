package com.projecthub.admin.ui;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.projecthub.admin.R;
import com.projecthub.admin.model.Project;
import com.projecthub.admin.utils.FirebaseHelper;
import com.projecthub.admin.utils.GitHubUploader;
import com.projecthub.admin.utils.ImgBBUploader;

import java.util.ArrayList;
import java.util.Arrays;

public class AddProjectActivity extends AppCompatActivity {

    private ImageView ivThumbnailPreview;
    private TextView tvThumbnailHint, tvZipFileName, tvHeaderTitle;
    private ProgressBar progressThumbnail, progressZip;
    private EditText etName, etDeveloper, etDescription, etFeatures, etRequirements,
            etInstallGuide, etVersion, etFileSize, etDemoVideo, etLivePreview, etPrice, etDiscountPrice;
    private Spinner spinnerCategory;
    private SwitchMaterial switchCoupon, switchFeatured, switchTrending, switchBestSeller, switchFlashSale;

    private String uploadedThumbnailUrl;
    private String uploadedZipDownloadUrl;
    private String editingProjectId; // null when adding new

    private final ActivityResultLauncher<String> pickThumbnailLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onThumbnailPicked);

    private final ActivityResultLauncher<String> pickZipLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onZipPicked);

    private final String[] categories = {
            "Website Script", "Android Source Code", "Telegram Bot", "FLM Project",
            "E-commerce Script", "WordPress", "Firebase Project", "Flutter Project",
            "UI/UX Design", "Game Source Code", "API Script", "AI Tools", "Other Projects"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_project);
        bindViews();

        spinnerCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.cardThumbnail).setOnClickListener(v -> pickThumbnailLauncher.launch("image/*"));
        findViewById(R.id.cardZipUpload).setOnClickListener(v -> pickZipLauncher.launch("application/zip"));
        findViewById(R.id.btnSaveProject).setOnClickListener(v -> saveProject());

        editingProjectId = getIntent().getStringExtra("projectId");
        if (editingProjectId != null) {
            tvHeaderTitle.setText("Edit Project");
            loadExistingProject(editingProjectId);
        }
    }

    private void bindViews() {
        ivThumbnailPreview = findViewById(R.id.ivThumbnailPreview);
        tvThumbnailHint = findViewById(R.id.tvThumbnailHint);
        tvZipFileName = findViewById(R.id.tvZipFileName);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);
        progressThumbnail = findViewById(R.id.progressThumbnail);
        progressZip = findViewById(R.id.progressZip);

        etName = findViewById(R.id.etName);
        etDeveloper = findViewById(R.id.etDeveloper);
        etDescription = findViewById(R.id.etDescription);
        etFeatures = findViewById(R.id.etFeatures);
        etRequirements = findViewById(R.id.etRequirements);
        etInstallGuide = findViewById(R.id.etInstallGuide);
        etVersion = findViewById(R.id.etVersion);
        etFileSize = findViewById(R.id.etFileSize);
        etDemoVideo = findViewById(R.id.etDemoVideo);
        etLivePreview = findViewById(R.id.etLivePreview);
        etPrice = findViewById(R.id.etPrice);
        etDiscountPrice = findViewById(R.id.etDiscountPrice);
        spinnerCategory = findViewById(R.id.spinnerCategory);

        switchCoupon = findViewById(R.id.switchCoupon);
        switchFeatured = findViewById(R.id.switchFeatured);
        switchTrending = findViewById(R.id.switchTrending);
        switchBestSeller = findViewById(R.id.switchBestSeller);
        switchFlashSale = findViewById(R.id.switchFlashSale);
    }

    // ---------- Thumbnail: auto-upload to ImgBB the moment it's picked ----------
    private void onThumbnailPicked(Uri uri) {
        if (uri == null) return;
        progressThumbnail.setVisibility(View.VISIBLE);
        tvThumbnailHint.setVisibility(View.GONE);
        Glide.with(this).load(uri).into(ivThumbnailPreview);

        ImgBBUploader.upload(this, uri, new ImgBBUploader.UploadCallback() {
            @Override
            public void onSuccess(String imageUrl) {
                runOnUiThread(() -> {
                    progressThumbnail.setVisibility(View.GONE);
                    uploadedThumbnailUrl = imageUrl;
                    Toast.makeText(AddProjectActivity.this, "Thumbnail uploaded", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    progressThumbnail.setVisibility(View.GONE);
                    tvThumbnailHint.setVisibility(View.VISIBLE);
                    Toast.makeText(AddProjectActivity.this, "Thumbnail upload failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ---------- ZIP: auto-upload to GitHub the moment it's picked ----------
    private void onZipPicked(Uri uri) {
        if (uri == null) return;
        String fileName = queryFileName(uri);
        tvZipFileName.setText("Uploading " + fileName + " ...");
        progressZip.setVisibility(View.VISIBLE);

        long bytes = querySizeBytes(uri);
        if (bytes > 0) {
            double mb = bytes / (1024.0 * 1024.0);
            etFileSize.setText(String.format("%.1f MB", mb));
        }

        String safeName = System.currentTimeMillis() + "_" + fileName;
        GitHubUploader.uploadZip(this, uri, safeName, new GitHubUploader.UploadCallback() {
            @Override
            public void onSuccess(String downloadUrl, String path) {
                runOnUiThread(() -> {
                    progressZip.setVisibility(View.GONE);
                    uploadedZipDownloadUrl = downloadUrl;
                    tvZipFileName.setText(fileName + " uploaded to GitHub");
                    Toast.makeText(AddProjectActivity.this, "Project file uploaded", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    progressZip.setVisibility(View.GONE);
                    tvZipFileName.setText("Upload failed — tap to retry");
                    Toast.makeText(AddProjectActivity.this, "GitHub upload failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private String queryFileName(Uri uri) {
        String result = "project.zip";
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx != -1) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private long querySizeBytes(Uri uri) {
        long size = -1;
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (idx != -1) size = cursor.getLong(idx);
            }
        } catch (Exception ignored) {}
        return size;
    }

    // ---------- Save to Firebase ----------
    private void saveProject() {
        String name = etName.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            etName.setError("Required");
            return;
        }
        if (uploadedThumbnailUrl == null && editingProjectId == null) {
            Toast.makeText(this, "Please wait for thumbnail upload to finish", Toast.LENGTH_SHORT).show();
            return;
        }

        Project project = new Project();
        project.name = name;
        project.category = spinnerCategory.getSelectedItem() != null ? spinnerCategory.getSelectedItem().toString() : "";
        project.thumbnailUrl = uploadedThumbnailUrl;
        project.developerName = etDeveloper.getText().toString().trim();
        project.description = etDescription.getText().toString().trim();
        project.features = new ArrayList<>(Arrays.asList(etFeatures.getText().toString().split("\\n")));
        project.requirements = new ArrayList<>(Arrays.asList(etRequirements.getText().toString().split("\\n")));
        project.installationGuide = etInstallGuide.getText().toString().trim();
        project.version = etVersion.getText().toString().trim();
        project.fileSize = etFileSize.getText().toString().trim();
        project.demoVideoLink = etDemoVideo.getText().toString().trim();
        project.livePreviewLink = etLivePreview.getText().toString().trim();
        project.downloadFileUrl = uploadedZipDownloadUrl;

        try {
            project.price = Double.parseDouble(etPrice.getText().toString().trim());
        } catch (Exception e) { project.price = 0; }
        try {
            project.discountPrice = Double.parseDouble(etDiscountPrice.getText().toString().trim());
        } catch (Exception e) { project.discountPrice = 0; }

        project.couponAvailable = switchCoupon.isChecked();
        project.featured = switchFeatured.isChecked();
        project.trending = switchTrending.isChecked();
        project.bestSeller = switchBestSeller.isChecked();
        project.flashSale = switchFlashSale.isChecked();
        project.visible = true;
        project.updateDate = System.currentTimeMillis();

        if (editingProjectId != null) {
            FirebaseHelper.projects().child(editingProjectId).setValue(project)
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Project updated", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
        } else {
            project.createdAt = System.currentTimeMillis();
            String key = FirebaseHelper.projects().push().getKey();
            FirebaseHelper.projects().child(key).setValue(project)
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Project added", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void loadExistingProject(String projectId) {
        FirebaseHelper.projects().child(projectId).get().addOnSuccessListener(snapshot -> {
            Project p = snapshot.getValue(Project.class);
            if (p == null) return;
            etName.setText(p.name);
            etDeveloper.setText(p.developerName);
            etDescription.setText(p.description);
            if (p.features != null) etFeatures.setText(TextUtils.join("\n", p.features));
            if (p.requirements != null) etRequirements.setText(TextUtils.join("\n", p.requirements));
            etInstallGuide.setText(p.installationGuide);
            etVersion.setText(p.version);
            etFileSize.setText(p.fileSize);
            etDemoVideo.setText(p.demoVideoLink);
            etLivePreview.setText(p.livePreviewLink);
            etPrice.setText(String.valueOf(p.price));
            etDiscountPrice.setText(String.valueOf(p.discountPrice));
            switchCoupon.setChecked(p.couponAvailable);
            switchFeatured.setChecked(p.featured);
            switchTrending.setChecked(p.trending);
            switchBestSeller.setChecked(p.bestSeller);
            switchFlashSale.setChecked(p.flashSale);
            uploadedThumbnailUrl = p.thumbnailUrl;
            uploadedZipDownloadUrl = p.downloadFileUrl;
            tvThumbnailHint.setVisibility(View.GONE);
            Glide.with(this).load(p.thumbnailUrl).into(ivThumbnailPreview);
            if (p.downloadFileUrl != null) tvZipFileName.setText("Existing file linked");

            int catIndex = Arrays.asList(categories).indexOf(p.category);
            if (catIndex >= 0) spinnerCategory.setSelection(catIndex);
        });
    }
}
