package com.projecthub.admin.api;

import com.google.gson.annotations.SerializedName;

public class GitHubUploadRequest {
    @SerializedName("message")
    public String message;

    @SerializedName("content")
    public String content; // base64 encoded file content

    @SerializedName("branch")
    public String branch;

    public GitHubUploadRequest(String message, String content, String branch) {
        this.message = message;
        this.content = content;
        this.branch = branch;
    }
}
