package com.projecthub.admin.ui;

public class UserDetailsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "User Details";
    }
}
