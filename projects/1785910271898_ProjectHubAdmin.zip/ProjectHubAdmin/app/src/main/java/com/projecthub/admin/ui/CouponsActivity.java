package com.projecthub.admin.ui;

public class CouponsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Coupons";
    }
}
