package com.projecthub.admin.api;

import com.google.gson.annotations.SerializedName;

public class ImgBBResponse {
    @SerializedName("data")
    public Data data;

    @SerializedName("success")
    public boolean success;

    @SerializedName("status")
    public int status;

    public static class Data {
        @SerializedName("id")
        public String id;

        @SerializedName("url")
        public String url;

        @SerializedName("display_url")
        public String displayUrl;

        @SerializedName("delete_url")
        public String deleteUrl;
    }
}
