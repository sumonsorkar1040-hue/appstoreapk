package com.projecthub.admin.ui;

public class BannersActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Banners";
    }
}
