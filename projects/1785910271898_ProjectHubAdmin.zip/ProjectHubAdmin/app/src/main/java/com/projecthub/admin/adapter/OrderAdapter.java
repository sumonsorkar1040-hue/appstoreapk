package com.projecthub.admin.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.projecthub.admin.R;
import com.projecthub.admin.model.Order;
import com.projecthub.admin.ui.OrderDetailsActivity;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private final List<Order> orderList;

    public OrderAdapter(List<Order> orderList) {
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);
        holder.tvOrderId.setText("#" + order.orderId);
        holder.tvOrderProjectName.setText(order.projectName);
        holder.tvOrderAmount.setText(String.format("$%.2f", order.amount));
        holder.tvOrderStatus.setText(order.status);
        Glide.with(holder.itemView.getContext())
                .load(order.projectThumb)
                .placeholder(R.drawable.bg_card_rounded)
                .into(holder.ivOrderThumb);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), OrderDetailsActivity.class);
            intent.putExtra("orderId", order.orderId);
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        ImageView ivOrderThumb;
        TextView tvOrderId, tvOrderProjectName, tvOrderAmount, tvOrderStatus;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            ivOrderThumb = itemView.findViewById(R.id.ivOrderThumb);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderProjectName = itemView.findViewById(R.id.tvOrderProjectName);
            tvOrderAmount = itemView.findViewById(R.id.tvOrderAmount);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
        }
    }
}
