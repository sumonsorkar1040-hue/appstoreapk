package com.projecthub.admin.api;

import com.google.gson.annotations.SerializedName;

public class GitHubUploadResponse {
    @SerializedName("content")
    public Content content;

    public static class Content {
        @SerializedName("name")
        public String name;

        @SerializedName("path")
        public String path;

        @SerializedName("download_url")
        public String downloadUrl; // raw.githubusercontent.com direct link

        @SerializedName("html_url")
        public String htmlUrl;
    }
}
