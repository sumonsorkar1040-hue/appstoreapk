package com.projecthub.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.projecthub.admin.R;
import com.projecthub.admin.adapter.OrderAdapter;
import com.projecthub.admin.model.Order;
import com.projecthub.admin.utils.FirebaseHelper;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvUsersValue, tvProjectsValue, tvSalesValue, tvEarningsValue;
    private LineChart lineChartSales;
    private RecyclerView rvRecentOrders;
    private final List<Order> recentOrders = new ArrayList<>();
    private OrderAdapter orderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        bindStatCard(R.id.cardTotalUsers, "Total Users", android.R.drawable.ic_menu_myplaces);
        bindStatCard(R.id.cardTotalProjects, "Total Projects", android.R.drawable.ic_menu_agenda);
        bindStatCard(R.id.cardTotalSales, "Total Sales", android.R.drawable.ic_menu_sort_by_size);
        bindStatCard(R.id.cardTotalEarnings, "Total Earnings", android.R.drawable.ic_menu_send);

        lineChartSales = findViewById(R.id.lineChartSales);
        rvRecentOrders = findViewById(R.id.rvRecentOrders);
        rvRecentOrders.setLayoutManager(new LinearLayoutManager(this));
        orderAdapter = new OrderAdapter(recentOrders);
        rvRecentOrders.setAdapter(orderAdapter);

        setupBottomNav();
        loadDashboardStats();
        loadRecentOrders();
        loadSalesChart();

        findViewById(R.id.btnNotifications).setOnClickListener(v ->
                startActivity(new Intent(this, SendNotificationActivity.class)));

        findViewById(R.id.tvViewAllOrders).setOnClickListener(v ->
                startActivity(new Intent(this, OrdersActivity.class)));
    }

    /** Binds an icon + label onto one of the reusable item_stat_card includes. */
    private void bindStatCard(int includeId, String label, int iconRes) {
        View root = findViewById(includeId);
        ImageView icon = root.findViewById(R.id.ivStatIcon);
        TextView tvLabel = root.findViewById(R.id.tvStatLabel);
        icon.setImageResource(iconRes);
        tvLabel.setText(label);
        root.setTag(label);
    }

    private TextView valueOf(int includeId) {
        return ((View) findViewById(includeId)).findViewById(R.id.tvStatValue);
    }

    private void loadDashboardStats() {
        // Total Users
        FirebaseHelper.users().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                valueOf(R.id.cardTotalUsers).setText(String.valueOf(snapshot.getChildrenCount()));
            }
            @Override public void onCancelled(DatabaseError error) {}
        });

        // Total Projects
        FirebaseHelper.projects().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                valueOf(R.id.cardTotalProjects).setText(String.valueOf(snapshot.getChildrenCount()));
            }
            @Override public void onCancelled(DatabaseError error) {}
        });

        // Total Sales (order count) + Total Earnings (sum of amount for Completed/Paid orders)
        FirebaseHelper.orders().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long totalOrders = snapshot.getChildrenCount();
                double totalEarnings = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Order order = child.getValue(Order.class);
                    if (order != null && ("Paid".equals(order.status) || "Completed".equals(order.status))) {
                        totalEarnings += order.amount;
                    }
                }
                valueOf(R.id.cardTotalSales).setText(String.valueOf(totalOrders));
                valueOf(R.id.cardTotalEarnings).setText(String.format("$%.0f", totalEarnings));
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void loadRecentOrders() {
        FirebaseHelper.orders().limitToLast(10).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                recentOrders.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Order order = child.getValue(Order.class);
                    if (order != null) {
                        order.orderId = child.getKey();
                        recentOrders.add(0, order);
                    }
                }
                orderAdapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    /** Builds the Sales Overview line chart from /Analytics/DailySales/{day}=amount */
    private void loadSalesChart() {
        FirebaseHelper.analytics().child("DailySales").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<Entry> entries = new ArrayList<>();
                int index = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Double value = child.getValue(Double.class);
                    entries.add(new Entry(index++, value == null ? 0f : value.floatValue()));
                }
                if (entries.isEmpty()) return;

                LineDataSet dataSet = new LineDataSet(entries, "Sales");
                dataSet.setColor(getColor(R.color.primary));
                dataSet.setLineWidth(2.5f);
                dataSet.setCircleColor(getColor(R.color.primary));
                dataSet.setDrawValues(false);
                dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

                lineChartSales.setData(new LineData(dataSet));
                lineChartSales.getDescription().setEnabled(false);
                lineChartSales.getAxisRight().setEnabled(false);
                lineChartSales.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
                lineChartSales.animateX(600);
                lineChartSales.invalidate();
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_dashboard);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                return true;
            } else if (id == R.id.nav_projects) {
                startActivity(new Intent(this, ProjectsActivity.class));
                return true;
            } else if (id == R.id.nav_orders) {
                startActivity(new Intent(this, OrdersActivity.class));
                return true;
            } else if (id == R.id.nav_users) {
                startActivity(new Intent(this, UsersActivity.class));
                return true;
            } else if (id == R.id.nav_more) {
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }
}
