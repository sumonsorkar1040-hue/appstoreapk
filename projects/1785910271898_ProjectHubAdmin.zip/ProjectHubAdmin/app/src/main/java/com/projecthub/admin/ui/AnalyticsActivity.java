package com.projecthub.admin.ui;

public class AnalyticsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Analytics";
    }
}
