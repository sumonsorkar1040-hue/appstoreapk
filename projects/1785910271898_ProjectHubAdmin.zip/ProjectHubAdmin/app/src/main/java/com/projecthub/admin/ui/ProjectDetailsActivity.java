package com.projecthub.admin.ui;

public class ProjectDetailsActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Project Details";
    }
}
