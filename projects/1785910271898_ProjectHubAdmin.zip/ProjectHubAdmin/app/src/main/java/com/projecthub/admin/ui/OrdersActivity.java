package com.projecthub.admin.ui;

public class OrdersActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Orders";
    }
}
