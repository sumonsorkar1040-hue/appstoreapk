package com.projecthub.admin.model;

public class AppUser {
    public String uid;
    public String name;
    public String email;
    public String phone;
    public String profileImage;
    public boolean verified;
    public boolean blocked;
    public double totalSpent;
    public int totalOrders;
    public String referralCode;
    public String referredBy;
    public long joinedAt;

    public AppUser() {
    }
}
