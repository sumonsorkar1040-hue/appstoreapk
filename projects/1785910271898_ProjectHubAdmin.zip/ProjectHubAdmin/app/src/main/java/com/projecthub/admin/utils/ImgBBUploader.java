package com.projecthub.admin.utils;

import android.content.Context;
import android.net.Uri;

import com.projecthub.admin.BuildConfig;
import com.projecthub.admin.api.ImgBBResponse;
import com.projecthub.admin.api.RetrofitClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Handles automatic image upload to ImgBB (https://api.imgbb.com/).
 * Usage:
 *   ImgBBUploader.upload(context, imageUri, new ImgBBUploader.UploadCallback() {
 *       public void onSuccess(String imageUrl) { ... }
 *       public void onError(String error) { ... }
 *   });
 */
public class ImgBBUploader {

    public interface UploadCallback {
        void onSuccess(String imageUrl);
        void onError(String error);
    }

    public static void upload(Context context, Uri imageUri, UploadCallback callback) {
        try {
            File file = copyUriToTempFile(context, imageUri);
            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            MultipartBody.Part part = MultipartBody.Part.createFormData("image", file.getName(), requestFile);

            Call<ImgBBResponse> call = RetrofitClient.getImgBBService()
                    .uploadImage(BuildConfig.IMGBB_API_KEY, part);

            call.enqueue(new Callback<ImgBBResponse>() {
                @Override
                public void onResponse(Call<ImgBBResponse> call, Response<ImgBBResponse> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                        callback.onSuccess(response.body().data.url);
                    } else {
                        callback.onError("ImgBB upload failed: HTTP " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<ImgBBResponse> call, Throwable t) {
                    callback.onError(t.getMessage());
                }
            });
        } catch (Exception e) {
            callback.onError(e.getMessage());
        }
    }

    private static File copyUriToTempFile(Context context, Uri uri) throws Exception {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        File tempFile = File.createTempFile("upload_", ".jpg", context.getCacheDir());
        try (FileOutputStream out = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[4096];
            int read;
            while (inputStream != null && (read = inputStream.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
        }
        if (inputStream != null) inputStream.close();
        return tempFile;
    }
}
