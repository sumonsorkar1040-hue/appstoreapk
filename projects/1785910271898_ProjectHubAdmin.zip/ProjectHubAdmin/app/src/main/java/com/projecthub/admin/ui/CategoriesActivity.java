package com.projecthub.admin.ui;

public class CategoriesActivity extends BasePlaceholderActivity {
    @Override
    protected String getScreenTitle() {
        return "Categories";
    }
}
