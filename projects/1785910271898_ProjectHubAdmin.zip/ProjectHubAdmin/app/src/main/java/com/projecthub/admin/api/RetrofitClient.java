package com.projecthub.admin.api;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static Retrofit imgbbRetrofit;
    private static Retrofit githubRetrofit;

    private static OkHttpClient buildClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);
        return new OkHttpClient.Builder()
                .addInterceptor(logging)
                .build();
    }

    public static ImgBBApiService getImgBBService() {
        if (imgbbRetrofit == null) {
            imgbbRetrofit = new Retrofit.Builder()
                    .baseUrl("https://api.imgbb.com/")
                    .client(buildClient())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return imgbbRetrofit.create(ImgBBApiService.class);
    }

    public static GitHubApiService getGitHubService() {
        if (githubRetrofit == null) {
            githubRetrofit = new Retrofit.Builder()
                    .baseUrl("https://api.github.com/")
                    .client(buildClient())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return githubRetrofit.create(GitHubApiService.class);
    }
}
