# ProjectHub Admin — Setup Guide (AndroidIDE / Android Studio, Java)

এই প্রজেক্টটা **AndroidIDE** অথবা **Android Studio** — দুটোতেই ওপেন করে সরাসরি বিল্ড করা যাবে (Gradle 8.9, AGP 8.6.0, compileSdk 35, Java 17)।

## যা যা এখন কাজ করছে (fully functional)

1. **Splash + Firebase Auth Login** — admin role verification, Forgot Password
2. **Dashboard** — real-time Total Users / Projects / Sales / Earnings, sales line chart, recent orders list
3. **Projects list** — real-time, Edit / Hide-Show / Delete
4. **Add / Edit Project** — thumbnail auto-upload to **ImgBB**, project **.zip** auto-upload directly to **GitHub**, full field set (features, requirements, pricing, toggles, etc.)
5. **Users list** — live search, block/unblock, verify badge, delete (long-press a user card)
6. **Send Notification** — queues a notification request in `/Notifications` in Firebase

## যা placeholder হিসেবে আছে (next update এ পূর্ণাঙ্গ করে দেব)

Order Details, Orders list, Categories, Analytics, Settings, Coupons, Banners, Reviews, User Details — এগুলোর জন্য এখন একটা simple "coming soon" স্ক্রিন আছে যাতে পুরো অ্যাপ কম্পাইল ও রান হয় সমস্যা ছাড়া। বলুন কোনটা আগে দরকার, আমি সেটা পরের ধাপে পুরোপুরি বানিয়ে দেব।

---

## যা যা এখন আপনাকে বসিয়ে দিতে হবে

### ১) Firebase Project
1. https://console.firebase.google.com এ গিয়ে নতুন প্রজেক্ট বানান
2. Android app যোগ করুন, package name দিন ঠিক এটাই: `com.projecthub.admin`
3. `google-services.json` ডাউনলোড করে **`app/google-services.json`** ফাইলটা রিপ্লেস করুন (এখন যেটা আছে ওটা শুধু placeholder, আসলটা না বসালে বিল্ড হবে না)
4. Firebase Console এ চালু করুন:
   - **Authentication → Email/Password**
   - **Realtime Database** (test mode বা আপনার rules দিয়ে শুরু করুন)
   - **Cloud Messaging**

### ২) প্রথম Admin অ্যাকাউন্ট বানানো
1. Firebase Console → Authentication → Add User দিয়ে একটা email/password বানান
2. Realtime Database এ ম্যানুয়ালি এই নোড বানান (Multiple Admin support এর জন্য এটাই key):
```
Admins/
   {সেই user এর UID}/
      email: "admin@example.com"
      role: "superadmin"
      status: "active"
```
UID টা Authentication ট্যাবে user এর পাশে পাবেন।

### ৩) ImgBB API Key (auto image upload)
1. https://api.imgbb.com এ গিয়ে ফ্রি অ্যাকাউন্ট বানিয়ে API key নিন
2. `app/build.gradle` ফাইলে এই লাইনটা বসান:
```groovy
buildConfigField "String", "IMGBB_API_KEY", "\"এখানে আপনার আসল key\""
```

### ৪) GitHub Token (auto .zip upload)
1. GitHub → Settings → Developer settings → **Personal access tokens (classic)** → Generate new token, `repo` scope দিন
2. একটা repository বানান যেখানে zip ফাইলগুলো যাবে (private repo রাখাই ভালো, downloadUrl raw.githubusercontent.com এর মাধ্যমে পাবেন)
3. `app/build.gradle` এ বসান:
```groovy
buildConfigField "String", "GITHUB_TOKEN", "\"ghp_xxxxxxxxxxxx\""
buildConfigField "String", "GITHUB_OWNER", "\"আপনার-github-username\""
buildConfigField "String", "GITHUB_REPO", "\"আপনার-repo-name\""
```
Contents API single-request upload প্রায় 25MB পর্যন্ত ভালো কাজ করে। এর বেশি বড় zip এর জন্য বলবেন, আমি Git Data (blob) API variant বানিয়ে দেব যেটা বড় ফাইলের জন্য দরকার।

### ৫) Categories seed করা (প্রথমবার)
Realtime Database এ ম্যানুয়ালি বা অ্যাপ থেকে (Categories module পরে আসবে) — এখন চাইলে সরাসরি ডাটাবেজে বসিয়ে দিন:
```
Categories/
   cat1/ { name: "Website Script" }
   cat2/ { name: "Android Source Code" }
   ...
```
(Add Project ফর্মে category dropdown আপাতত app এর ভেতরের hardcoded ১৩টা ক্যাটাগরি থেকেই আসছে — আপনার পিকচার অনুযায়ী।)

---

## Firebase Realtime Database Rules (শুরুর জন্য, পরে শক্ত করে নেবেন)

```json
{
  "rules": {
    "Admins": { ".read": "auth != null", ".write": "auth != null" },
    "Users": { ".read": "auth != null", ".write": "auth != null" },
    "Projects": { ".read": true, ".write": "auth != null" },
    "Orders": { ".read": "auth != null", ".write": "auth != null" },
    "Notifications": { ".read": "auth != null", ".write": "auth != null" },
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

## FCM নিয়ে একটা গুরুত্বপূর্ণ নোট
Server key ফোনের মধ্যে রেখে সরাসরি FCM push পাঠানো নিরাপদ না (key leak হয়ে যেতে পারে)। তাই এই অ্যাপে "Send Notification" স্ক্রিনটা `/Notifications` নোডে রিকোয়েস্ট জমা রাখে (status: "queued")। এরপর একটা ছোট Firebase Cloud Function (Node.js, কয়েক লাইনের) সেই নোড শুনে আসল push পাঠাবে। চাইলে সেই Cloud Function কোডটাও বানিয়ে দিতে পারি — বলুন।

---

## পরের ধাপে যা বানাবো (বলুন কোনটা আগে চান)
- Orders / Order Details full CRUD + refund flow
- Categories full CRUD (icon + image + count)
- Analytics screen (charts: top categories, revenue)
- Settings (app name/logo/maintenance mode/payment methods)
- Coupons, Banners, Reviews modules
- Payment gateway (bKash/Nagad/Rocket manual verification UI, Stripe/PayPal)
- Referral system screen
- Firebase Cloud Function for FCM dispatch + large-file GitHub upload variant
