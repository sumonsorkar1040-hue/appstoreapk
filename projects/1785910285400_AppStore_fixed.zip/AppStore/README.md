# App Store — User App (Phase 1: User-facing app)

Kotlin + XML (ViewBinding, Navigation Component, MVVM) Android project for AndroidIDE.
This phase covers the **User App**: Splash → Onboarding → Auth → Home/Apps/Games/Updates/Profile → App Detail → Download/Install.
The **Admin Panel** (publish apps, imgbb image upload, APK upload to Firebase Storage) is a separate phase, not yet included.

## 1. Open in AndroidIDE
1. Copy this whole `AppStore/` folder onto your device (or `git clone` if you push it to GitHub first).
2. Open AndroidIDE → "Open Project" → select the `AppStore` folder.
3. Let Gradle sync. First sync will download dependencies — needs a good internet connection.

## 2. Connect Firebase
This app and the companion **Admin Panel** (AppStoreAdmin) must point at the **same
Firebase project** and use **Cloud Firestore** (not Realtime Database) — that's the
only database the admin panel writes to, so anything added from the admin panel only
shows up here if both apps share the project and the security rules below are deployed.

1. Go to the [Firebase Console](https://console.firebase.google.com) → Create/select a project
   (reuse the same project the Admin Panel uses).
2. Add an Android app with package name **`com.appstore.user`**.
3. Download `google-services.json` and place it at:
   `app/google-services.json`
4. Enable in the console:
   - **Authentication** → Sign-in methods: Email/Password, Google
   - **Cloud Firestore** → create the database, then deploy the rules from the Admin
     Panel project's `firestore.rules` (Firestore Database → Rules in the console, or
     `firebase deploy --only firestore:rules`). A locked-down "admins only" rule set
     blocks this app from ever reading the catalog, which looks exactly like "apps
     added in the admin panel don't show up".
   - **Storage** → for APK files (used later by the Admin Panel)
   - **Cloud Messaging** → for push notifications
   - **App Check** → register with Play Integrity (required by `AppStoreApplication`)
5. For Google Sign-In, copy the **Web client ID** from
   Firebase Console → Project Settings → General → "Your apps" → the auto-generated
   `default_web_client_id` (this is generated automatically into your resources
   once `google-services.json` is added — no manual step needed).

> Note: `database.rules.json` in this repo is left over from an earlier Realtime
> Database version of this app and is no longer used — this app only talks to
> Firestore now (see `AppRepository.kt`). You can ignore it.

## 3. Cloud Firestore structure
The app reads/writes these Firestore collections (see `Constants.kt` and
`AppRepository.kt`), using the **exact same field names** the Admin Panel's
`FirebaseRepository`/`AppModel` write:

```
apps/{appId}          -> admin's AppModel fields (appName, apkDownloadUrl, status, ...)
categories/{catId}    -> Category
banners/{bannerId}    -> Banner
reviews/{reviewId}    -> Review (has an appId field)
users/{uid}           -> UserModel
settings/config       -> maintenanceMode, appUpdate, privacyPolicy
notifications/{uid}/items/{id} -> per-user notification inbox
```

Only apps with `status == "PUBLISHED"` are shown to end users — set that from the
Admin Panel's Apps screen (or the "Publish immediately" toggle when adding a new app).
You can also seed sample data manually from the Firebase console
(Firestore Database → Start collection), matching the fields in `AppModel.kt`.

## 4. imgbb (for Admin Panel, next phase)
`Constants.IMGBB_API_KEY` is a placeholder. When we build the Admin Panel, screenshots/icons
will upload directly to imgbb using this key, and the returned image URL gets saved into
`Apps/{appId}/iconUrl` / `screenshots`.

## 5. What's implemented in this phase
- Splash: internet check, maintenance-mode check, root/emulator soft-warning, auto-login routing
- Onboarding (skippable, 4 pages)
- Auth: Email/Password login & register, Forgot Password, Google Sign-In, screenshot-protected screens
- Bottom Nav: Home, Apps, Games, Updates, Profile
- Home: banner slider + 6 horizontal sections (Featured, Editor's Choice, Trending, New Releases, Top Charts, Featured Games), tappable search bar, notification bell
- Apps/Games: category chips + vertical list
- Updates: detects installed apps with a newer store version (via `PackageManager`) and lets you update them, "Update All"
- App Detail: icon/rating/downloads, screenshots gallery, description, what's new, reviews list, similar apps, Install/Update/Open button with real download progress via Android `DownloadManager` + APK install via `FileProvider`, Wishlist heart, Favorite bookmark, Share
- **Search**: instant (debounced) search, voice search (mic → speech-to-text), recent search history, trending searches
- **Write a Review**: star rating + comment, auto-recomputes the app's aggregate rating
- **Wishlist / Favorites**: dedicated tabbed screen (`CollectionsActivity`) reachable from Profile or the heart/bookmark icons on App Detail
- **Notifications**: live list from `Notifications/{uid}`, tap to mark read and deep-link to the app
- Profile: user info, dark mode toggle, wishlist/favorites shortcuts, logout
- Dark/Light theme (Material 3)
- Firebase offline persistence + App Check (Play Integrity)
- **Security**: root & emulator heuristic detection (soft warning on Splash), `FLAG_SECURE` screenshot/recording protection on Login, Register and the Profile tab

## 6. Not yet built (next phase)
- Admin Panel (publish/edit apps, imgbb upload, APK upload to Storage)
- Download History screen, Notification Settings screen (rows exist in Profile but aren't wired up yet)

## 7. Required permissions
`INTERNET`, `POST_NOTIFICATIONS`, `REQUEST_INSTALL_PACKAGES` (to install downloaded APKs — the
user will be prompted once to allow "install unknown apps" for this app).

## 8. Package name
`com.appstore.user` — change it in `app/build.gradle.kts` (`namespace` + `applicationId`) and in
`AndroidManifest.xml` package references before you publish, and re-download `google-services.json`
to match.
