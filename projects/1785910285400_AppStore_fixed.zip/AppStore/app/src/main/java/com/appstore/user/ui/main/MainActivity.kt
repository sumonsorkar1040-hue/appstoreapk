package com.appstore.user.ui.main

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.marginBottom
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.databinding.ActivityMainBinding
import com.appstore.user.utils.NetworkUtils
import com.appstore.user.utils.SecurityHelper
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var baseNavBottomMargin = -1

    private val repository = AppRepository()
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Light status bar: white background with dark icons
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar/nav bar
        // would otherwise overlap the top search bar and the floating bottom nav card.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.navHostFragment.updatePadding(top = systemBars.top)
            if (baseNavBottomMargin < 0) baseNavBottomMargin = binding.bottomNav.marginBottom
            binding.bottomNav.updateLayoutParams<android.view.ViewGroup.MarginLayoutParams> {
                bottomMargin = baseNavBottomMargin + systemBars.bottom
            }
            insets
        }

        val navHostFragment = supportFragmentManager
            .findFragmentById(binding.navHostFragment.id) as NavHostFragment
        val navController = navHostFragment.navController

        binding.bottomNav.setupWithNavController(navController)

        // Personal info (Profile) is sensitive: block screenshots/screen recording while it's shown.
        navController.addOnDestinationChangedListener { _, destination, _ ->
            if (destination.id == com.appstore.user.R.id.profileFragment) {
                SecurityHelper.applyScreenshotProtection(this)
            } else {
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            }
        }

        // Splash screen was removed so the app opens straight into this screen — these
        // used to gate entry from SplashActivity; now they just run quietly in the
        // background and only interrupt with a dialog if something actually needs it.
        runStartupChecks()
    }

    private fun runStartupChecks() {
        if (!NetworkUtils.isOnline(this)) {
            showNoInternetDialog()
            return
        }
        lifecycleScope.launch {
            val underMaintenance = repository.isMaintenanceModeOn()
            if (underMaintenance) {
                showMaintenanceDialog()
            } else {
                checkDeviceIntegrity()
            }
        }
    }

    private fun checkDeviceIntegrity() {
        if (SecurityHelper.isDeviceRooted()) {
            AlertDialog.Builder(this)
                .setTitle("Security Notice")
                .setMessage("This device appears to be rooted. Some features may not work as expected, and downloaded apps are installed at your own risk.")
                .setCancelable(false)
                .setPositiveButton("Continue") { d, _ -> d.dismiss(); ensureSignedIn() }
                .show()
        } else {
            ensureSignedIn()
        }
    }

    /** Nobody should ever land on a forced Login screen just from opening the
     *  app — if there's no account yet, sign in as a Firebase anonymous
     *  "guest" so browsing works right away. A real account is only required
     *  later, when the person tries to upload an app. */
    private fun ensureSignedIn() {
        if (FirebaseAuth.getInstance().currentUser != null) return
        lifecycleScope.launch { authRepository.signInAsGuest() }
    }

    private fun showNoInternetDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(com.appstore.user.R.string.no_internet))
            .setCancelable(false)
            .setPositiveButton(getString(com.appstore.user.R.string.retry)) { d, _ ->
                d.dismiss(); runStartupChecks()
            }
            .show()
    }

    private fun showMaintenanceDialog() {
        AlertDialog.Builder(this)
            .setTitle("Under Maintenance")
            .setMessage("App Store is currently under maintenance. Please check back later.")
            .setCancelable(false)
            .setPositiveButton("Retry") { d, _ -> d.dismiss(); runStartupChecks() }
            .show()
    }
}
