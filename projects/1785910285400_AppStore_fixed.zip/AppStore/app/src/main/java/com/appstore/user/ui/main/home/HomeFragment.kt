package com.appstore.user.ui.main.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import com.bumptech.glide.Glide
import com.google.android.material.chip.Chip
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.R
import com.appstore.user.adapter.AppGridAdapter
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.adapter.BannerAdapter
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.model.Category
import com.appstore.user.databinding.FragmentHomeBinding
import com.appstore.user.databinding.LayoutHomeSectionBinding
import com.appstore.user.databinding.LayoutHomeSectionDynamicBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private var hasLoadedOnce = false

    private val bannerAdapter = BannerAdapter { banner ->
        if (banner.linkAppId.isNotEmpty()) openAppDetail(banner.linkAppId)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupBanners()
        setupSection(binding.sectionFeaturedApps, getString(R.string.featured_apps))
        setupSection(binding.sectionEditorsChoice, getString(R.string.editors_choice))
        setupSection(binding.sectionTrending, getString(R.string.trending_apps))
        setupSection(binding.sectionNewReleases, getString(R.string.new_releases))
        setupSection(binding.sectionTopCharts, getString(R.string.top_charts))
        setupSection(binding.sectionFeaturedGames, getString(R.string.featured_games))

        observeViewModel()

        binding.swipeRefresh.setOnRefreshListener { viewModel.loadHome() }
        binding.searchBar.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.search.SearchActivity::class.java))
        }
        binding.ivNotification.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.notifications.NotificationsActivity::class.java))
        }
        bindHomeProfilePic()
        binding.ivHomeProfile.setOnClickListener {
            findNavController().navigate(R.id.profileFragment)
        }
        viewModel.loadHome()
    }

    /** Shows the signed-in user's photo next to the notification bell; falls back
     *  to the placeholder icon already set in the layout for guests / no photo. */
    private fun bindHomeProfilePic() {
        val photoUrl = FirebaseAuth.getInstance().currentUser?.photoUrl
        if (photoUrl != null) {
            Glide.with(this).load(photoUrl).into(binding.ivHomeProfile)
        }
    }

    private fun setupBanners() {
        binding.rvBanners.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.rvBanners.adapter = bannerAdapter
        PagerSnapHelper().attachToRecyclerView(binding.rvBanners)
        binding.shimmerBannerPlaceholder.startShimmer()
    }

    private fun setupSection(section: LayoutHomeSectionBinding, title: String) {
        section.tvSectionTitle.text = title
        section.rvSectionItems.layoutManager = LinearLayoutManager(requireContext())
        section.rvSectionItems.isNestedScrollingEnabled = false
        section.rvSectionItems.adapter = AppListAdapter(
            actionLabel = getString(R.string.get),
            onClick = { app -> openAppDetail(app.id) },
            onActionClick = { app -> openAppDetail(app.id) } // Install starts from detail screen for full info
        )
        section.rvSectionItems.visibility = View.GONE
        section.shimmerSectionItems.visibility = View.VISIBLE
        section.shimmerSectionItems.startShimmer()
    }

    private fun bindSection(section: LayoutHomeSectionBinding, apps: List<AppModel>) {
        (section.rvSectionItems.adapter as? AppListAdapter)?.submitList(apps)
        section.shimmerSectionItems.stopShimmer()
        section.shimmerSectionItems.visibility = View.GONE
        section.rvSectionItems.visibility = if (apps.isEmpty()) View.GONE else View.VISIBLE
        section.root.visibility = if (apps.isEmpty()) View.GONE else View.VISIBLE
    }

    /** Renders the unlimited, admin-created custom Home sections (e.g. "New Releases",
     *  "Top Charts", or any other name added from the Admin Panel). Each section starts
     *  in Grid view and can be toggled to List view via its header icon. */
    private fun renderDynamicSections(sections: List<HomeSectionWithApps>) {
        binding.llDynamicSections.removeAllViews()
        sections.forEach { (section, apps) ->
            if (apps.isEmpty()) return@forEach
            val sectionBinding = LayoutHomeSectionDynamicBinding.inflate(
                layoutInflater, binding.llDynamicSections, false
            )
            sectionBinding.tvSectionTitle.text = section.name

            var isGrid = true
            fun applyLayout() {
                if (isGrid) {
                    sectionBinding.rvSectionItems.layoutManager =
                        GridLayoutManager(requireContext(), 2)
                    sectionBinding.rvSectionItems.adapter = AppGridAdapter(
                        actionLabel = getString(R.string.get),
                        onClick = { app -> openAppDetail(app.id) },
                        onActionClick = { app -> openAppDetail(app.id) }
                    ).apply { submitList(apps) }
                    sectionBinding.ivToggleView.setImageResource(R.drawable.ic_view_list)
                } else {
                    sectionBinding.rvSectionItems.layoutManager = LinearLayoutManager(requireContext())
                    sectionBinding.rvSectionItems.adapter = AppListAdapter(
                        actionLabel = getString(R.string.get),
                        onClick = { app -> openAppDetail(app.id) },
                        onActionClick = { app -> openAppDetail(app.id) }
                    ).apply { submitList(apps) }
                    sectionBinding.ivToggleView.setImageResource(R.drawable.ic_view_grid)
                }
            }
            sectionBinding.rvSectionItems.isNestedScrollingEnabled = false
            applyLayout()
            sectionBinding.ivToggleView.setOnClickListener {
                isGrid = !isGrid
                applyLayout()
            }
            binding.llDynamicSections.addView(sectionBinding.root)
        }
    }

    private fun observeViewModel() {
        viewModel.banners.observe(viewLifecycleOwner) { banners ->
            bannerAdapter.submitList(banners)
            binding.shimmerBannerPlaceholder.stopShimmer()
            binding.shimmerBannerPlaceholder.visibility = View.GONE
            binding.rvBanners.visibility = if (banners.isEmpty()) View.GONE else View.VISIBLE
        }
        viewModel.categories.observe(viewLifecycleOwner) { populateCategoryChips(it) }
        viewModel.featuredApps.observe(viewLifecycleOwner) { bindSection(binding.sectionFeaturedApps, it) }
        viewModel.editorsChoice.observe(viewLifecycleOwner) { bindSection(binding.sectionEditorsChoice, it) }
        viewModel.trending.observe(viewLifecycleOwner) { bindSection(binding.sectionTrending, it) }
        viewModel.newReleases.observe(viewLifecycleOwner) { bindSection(binding.sectionNewReleases, it) }
        viewModel.topCharts.observe(viewLifecycleOwner) { bindSection(binding.sectionTopCharts, it) }
        viewModel.featuredGames.observe(viewLifecycleOwner) { bindSection(binding.sectionFeaturedGames, it) }
        viewModel.dynamicSections.observe(viewLifecycleOwner) { renderDynamicSections(it) }
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            // Each section/banner now shows its own shimmer while its data loads, so the
            // pull-to-refresh spinner is only needed for refreshes after the first load.
            if (!loading) hasLoadedOnce = true
            binding.swipeRefresh.isRefreshing = loading && hasLoadedOnce
        }
    }

    private fun populateCategoryChips(categories: List<Category>) {
        binding.chipGroupHomeCategories.removeAllViews()
        binding.chipGroupHomeCategories.isSingleSelection = true

        val chipForYou = buildHomeChip(Constants.CATEGORY_FOR_YOU).apply {
            isChecked = true
            setOnClickListener { openCategory(null) }
        }
        binding.chipGroupHomeCategories.addView(chipForYou)

        categories.forEach { category ->
            val chip = buildHomeChip(category.name).apply {
                setOnClickListener { openCategory(category.name) }
            }
            binding.chipGroupHomeCategories.addView(chip)
        }
    }

    /** Builds a category chip styled with the app's blue theme (filled when selected). */
    private fun buildHomeChip(label: String): Chip = Chip(requireContext()).apply {
        text = label
        isCheckable = true
        chipBackgroundColor = ContextCompat.getColorStateList(requireContext(), R.color.chip_category_background)
        setTextColor(ContextCompat.getColorStateList(requireContext(), R.color.chip_category_text))
        chipStrokeWidth = 0f
    }

    private fun openCategory(category: String?) {
        findNavController().navigate(
            R.id.appsFragment,
            category?.let { androidx.core.os.bundleOf("category" to it) }
        )
    }

    private fun openAppDetail(appId: String) {
        val intent = Intent(requireContext(), AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
