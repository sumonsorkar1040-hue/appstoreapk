package com.appstore.user.ui.search

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.speech.RecognizerIntent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.databinding.ActivitySearchBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants
import com.appstore.user.utils.PrefsHelper
import java.util.Locale

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private val viewModel: SearchViewModel by lazy { ViewModelProvider(this)[SearchViewModel::class.java] }
    private lateinit var prefs: PrefsHelper

    private val listAdapter = AppListAdapter(
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> openDetail(app.id) }
    )

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchVoiceSearch() else android.widget.Toast.makeText(this, "Microphone permission is needed for voice search", android.widget.Toast.LENGTH_SHORT).show()
    }

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                binding.etSearch.setText(text)
                binding.etSearch.setSelection(text.length)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true
        prefs = PrefsHelper(this)

        binding.rvResults.layoutManager = LinearLayoutManager(this)
        binding.rvResults.adapter = listAdapter

        binding.ivBack.setOnClickListener { finish() }
        binding.ivVoiceSearch.setOnClickListener { requestMicAndSearch() }
        binding.tvClearHistory.setOnClickListener { prefs.clearSearchHistory(); renderHistory() }

        binding.etSearch.addTextChangedListener { text ->
            val query = text?.toString().orEmpty()
            binding.ivClear.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE
            toggleSuggestionsVsResults(query)
            viewModel.onQueryChanged(query)
        }
        binding.ivClear.setOnClickListener { binding.etSearch.setText("") }

        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                commitSearch(binding.etSearch.text?.toString().orEmpty())
                true
            } else false
        }

        viewModel.results.observe(this) { list ->
            listAdapter.submitList(list)
            binding.emptyResults.visibility = if (list.isEmpty() && binding.etSearch.text?.isNotEmpty() == true) View.VISIBLE else View.GONE
        }
        viewModel.trending.observe(this) { renderTrending(it) }

        renderHistory()
        viewModel.loadTrending()

        intent.getStringExtra(Constants.EXTRA_QUERY)?.let {
            binding.etSearch.setText(it)
            commitSearch(it)
        }
    }

    private fun toggleSuggestionsVsResults(query: String) {
        val showResults = query.isNotBlank()
        binding.rvResults.visibility = if (showResults) View.VISIBLE else View.GONE
        binding.suggestionsContainer.visibility = if (showResults) View.GONE else View.VISIBLE
        if (!showResults) binding.emptyResults.visibility = View.GONE
    }

    private fun commitSearch(query: String) {
        if (query.isBlank()) return
        prefs.addSearchQuery(query)
        renderHistory()
        toggleSuggestionsVsResults(query)
        viewModel.searchNow(query)
    }

    private fun renderHistory() {
        val history = prefs.getSearchHistory()
        binding.chipGroupHistory.removeAllViews()
        history.forEach { query ->
            val chip = Chip(this).apply {
                text = query
                isCloseIconVisible = true
                setOnClickListener { binding.etSearch.setText(query); binding.etSearch.setSelection(query.length); commitSearch(query) }
                setOnCloseIconClickListener { prefs.removeSearchQuery(query); renderHistory() }
            }
            binding.chipGroupHistory.addView(chip)
        }
    }

    private fun renderTrending(keywords: List<String>) {
        binding.chipGroupTrending.removeAllViews()
        keywords.forEach { keyword ->
            val chip = Chip(this).apply {
                text = keyword
                setOnClickListener { binding.etSearch.setText(keyword); binding.etSearch.setSelection(keyword.length); commitSearch(keyword) }
            }
            binding.chipGroupTrending.addView(chip)
        }
    }

    private fun requestMicAndSearch() {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) launchVoiceSearch() else micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
    }

    private fun launchVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Search apps & games")
        }
        runCatching { voiceLauncher.launch(intent) }
    }

    private fun openDetail(appId: String) {
        val intent = Intent(this, AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }
}
