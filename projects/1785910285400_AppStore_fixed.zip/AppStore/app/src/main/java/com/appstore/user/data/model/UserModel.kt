package com.appstore.user.data.model

data class UserModel(
    var uid: String = "",
    var name: String = "",
    var phone: String = "",
    var email: String = "",
    var photoUrl: String = "",
    var wishlist: Map<String, Boolean> = emptyMap(),
    var favorites: Map<String, Boolean> = emptyMap(),
    var installedApps: Map<String, Boolean> = emptyMap(),
    var fcmToken: String = "",
    var createdAt: Long = 0,
    var isBanned: Boolean = false
)
