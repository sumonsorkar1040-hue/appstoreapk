package com.appstore.user.ui.collections

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.repository.AppRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class CollectionsViewModel : ViewModel() {

    private val repository = AppRepository()

    private val _wishlist = MutableLiveData<List<AppModel>>()
    val wishlist: LiveData<List<AppModel>> = _wishlist

    private val _favorites = MutableLiveData<List<AppModel>>()
    val favorites: LiveData<List<AppModel>> = _favorites

    fun load() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        viewModelScope.launch {
            val userModel = repository.getUserModel(uid)
            _wishlist.value = repository.getAppsByIds(userModel?.wishlist?.keys?.toList().orEmpty())
            _favorites.value = repository.getAppsByIds(userModel?.favorites?.keys?.toList().orEmpty())
        }
    }
}
