package com.appstore.user.utils

import android.content.Context

class PrefsHelper(context: Context) {
    private val prefs = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE)

    var onboardingDone: Boolean
        get() = prefs.getBoolean(Constants.PREF_ONBOARDING_DONE, false)
        set(value) = prefs.edit().putBoolean(Constants.PREF_ONBOARDING_DONE, value).apply()

    var darkMode: Boolean
        get() = prefs.getBoolean(Constants.PREF_DARK_MODE, false)
        set(value) = prefs.edit().putBoolean(Constants.PREF_DARK_MODE, value).apply()

    fun getSearchHistory(): List<String> {
        val raw = prefs.getString(Constants.PREF_SEARCH_HISTORY, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("||").filter { it.isNotBlank() }
    }

    fun addSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return
        val history = getSearchHistory().toMutableList()
        history.remove(trimmed)
        history.add(0, trimmed)
        val capped = history.take(Constants.SEARCH_HISTORY_MAX)
        prefs.edit().putString(Constants.PREF_SEARCH_HISTORY, capped.joinToString("||")).apply()
    }

    fun removeSearchQuery(query: String) {
        val history = getSearchHistory().toMutableList()
        history.remove(query)
        prefs.edit().putString(Constants.PREF_SEARCH_HISTORY, history.joinToString("||")).apply()
    }

    fun clearSearchHistory() {
        prefs.edit().remove(Constants.PREF_SEARCH_HISTORY).apply()
    }
}
