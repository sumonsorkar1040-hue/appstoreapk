package com.appstore.user.ui.search

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.repository.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SearchViewModel : ViewModel() {

    private val repository = AppRepository()
    private var searchJob: Job? = null

    private val _results = MutableLiveData<List<AppModel>>()
    val results: LiveData<List<AppModel>> = _results

    private val _trending = MutableLiveData<List<String>>()
    val trending: LiveData<List<String>> = _trending

    private val _isSearching = MutableLiveData(false)
    val isSearching: LiveData<Boolean> = _isSearching

    fun loadTrending() {
        viewModelScope.launch {
            val list = repository.getTrendingSearchKeywords()
            _trending.value = list.ifEmpty {
                listOf("Instagram", "WhatsApp", "Snapchat", "Telegram", "Spotify", "Netflix")
            }
        }
    }

    /** Debounces input by 350ms so we don't hit the DB on every keystroke. */
    fun onQueryChanged(query: String) {
        searchJob?.cancel()
        if (query.isBlank()) {
            _results.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            _isSearching.value = true
            _results.value = repository.searchApps(query)
            _isSearching.value = false
        }
    }

    fun searchNow(query: String) {
        searchJob?.cancel()
        viewModelScope.launch {
            _isSearching.value = true
            _results.value = repository.searchApps(query)
            _isSearching.value = false
        }
    }
}
