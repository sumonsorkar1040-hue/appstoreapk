package com.appstore.user.data.model

data class Review(
    var id: String = "",
    var appId: String = "",
    var userId: String = "",
    var userName: String = "",
    var userPhotoUrl: String = "",
    var rating: Float = 0f,
    var comment: String = "",
    var screenshotUrl: String = "",
    var helpfulCount: Long = 0,
    var timestamp: Long = 0
)
