package com.appstore.user.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.appstore.user.databinding.ItemScreenshotBinding

class ScreenshotAdapter(private val urls: List<String>) : RecyclerView.Adapter<ScreenshotAdapter.VH>() {
    inner class VH(val binding: ItemScreenshotBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemScreenshotBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        Glide.with(holder.itemView.context).load(urls[position]).centerCrop().into(holder.binding.ivScreenshot)
    }

    override fun getItemCount() = urls.size
}
