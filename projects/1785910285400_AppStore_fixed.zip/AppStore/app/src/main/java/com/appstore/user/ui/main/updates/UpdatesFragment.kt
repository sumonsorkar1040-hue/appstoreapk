package com.appstore.user.ui.main.updates

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.databinding.FragmentUpdatesBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants
import com.appstore.user.utils.DownloadManagerHelper

class UpdatesFragment : Fragment() {

    private var _binding: FragmentUpdatesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: UpdatesViewModel by viewModels()

    private val listAdapter = AppListAdapter(
        actionLabel = "Update",
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app ->
            DownloadManagerHelper(requireContext()).startDownload(app.apkUrl, app.name) {
                Toast.makeText(requireContext(), "Updating ${app.name}...", Toast.LENGTH_SHORT).show()
            }
        }
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentUpdatesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvUpdates.layoutManager = LinearLayoutManager(requireContext())
        binding.rvUpdates.adapter = listAdapter

        viewModel.updatableApps.observe(viewLifecycleOwner) { apps ->
            listAdapter.submitList(apps)
            binding.emptyState.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }
        viewModel.isLoading.observe(viewLifecycleOwner) { binding.swipeRefresh.isRefreshing = it }

        binding.swipeRefresh.setOnRefreshListener { viewModel.loadUpdates() }
        binding.btnUpdateAll.setOnClickListener {
            listAdapter.currentList.forEach { app ->
                DownloadManagerHelper(requireContext()).startDownload(app.apkUrl, app.name) {}
            }
            Toast.makeText(requireContext(), "Updating all apps...", Toast.LENGTH_SHORT).show()
        }

        viewModel.loadUpdates()
    }

    private fun openDetail(appId: String) {
        val intent = Intent(requireContext(), AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
