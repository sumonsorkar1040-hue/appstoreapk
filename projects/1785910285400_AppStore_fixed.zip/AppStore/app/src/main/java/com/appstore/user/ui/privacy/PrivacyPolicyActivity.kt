package com.appstore.user.ui.privacy

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityPrivacyPolicyBinding
import kotlinx.coroutines.launch

/**
 * "Privacy Policy" screen, reachable from Profile -> Privacy Policy.
 *
 * Shows the text set by the admin at /Settings/privacyPolicy (editable
 * from the Firebase console, or the Admin Panel once that phase is built).
 */
class PrivacyPolicyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyPolicyBinding
    private val repository = AppRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacyPolicyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the top bar. Pad the root container (not the
        // top bar itself) by the top inset, so the top bar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        binding.ivBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val policy = repository.getPrivacyPolicy()
            binding.progressBar.visibility = View.GONE
            binding.tvPrivacyPolicy.text = policy.ifBlank {
                "No privacy policy has been added yet. Please check back later."
            }
        }
    }
}
