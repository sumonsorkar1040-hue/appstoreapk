package com.appstore.user.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.appstore.user.data.model.NotificationItem
import com.appstore.user.databinding.ItemNotificationBinding

class NotificationAdapter(private val onClick: (NotificationItem) -> Unit) :
    ListAdapter<NotificationItem, NotificationAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemNotificationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemNotificationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.binding.tvTitle.text = item.title
        holder.binding.tvBody.text = item.body
        holder.binding.unreadDot.visibility = if (item.isRead) View.INVISIBLE else View.VISIBLE
        Glide.with(holder.itemView.context).load(item.imageUrl).centerCrop().into(holder.binding.ivIcon)
        holder.itemView.setOnClickListener { onClick(item) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<NotificationItem>() {
            override fun areItemsTheSame(oldItem: NotificationItem, newItem: NotificationItem) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: NotificationItem, newItem: NotificationItem) = oldItem == newItem
        }
    }
}
