package com.appstore.user.data.model

/**
 * An admin-created, unlimited Home-screen section (e.g. "New Releases",
 * "Top Charts", or any custom name) — created from the Admin Panel and
 * shown dynamically on the Home screen. Apps are attached to a section by
 * including its [id] in their own `homeSectionIds` list at publish time.
 */
data class HomeSection(
    var id: String = "",
    var name: String = "",
    var iconUrl: String = "",
    var isHidden: Boolean = false,
    var sortOrder: Int = 0
)
