package com.appstore.user.ui.update

import android.content.Context
import android.net.Uri
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.LifecycleCoroutineScope
import com.appstore.user.BuildConfig
import com.appstore.user.R
import com.appstore.user.data.model.AppUpdateInfo
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.DialogCheckUpdateBinding
import com.appstore.user.utils.DownloadManagerHelper
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

/**
 * The "Check & Update" pop-up, reachable from Profile -> Check & Update.
 *
 * Checks the current app's own version against /AppUpdate in Firebase
 * (populated/removed by the admin). Shows "you're up to date" or an
 * "update available" card with what's-new notes, then downloads and
 * installs the new APK in place.
 */
class CheckUpdateDialog(
    private val context: Context,
    private val lifecycleScope: LifecycleCoroutineScope
) {

    private val repository = AppRepository()
    private val downloadHelper = DownloadManagerHelper(context)

    private lateinit var binding: DialogCheckUpdateBinding
    private lateinit var dialog: AlertDialog
    private var activeDownloadId: Long = -1

    fun show() {
        binding = DialogCheckUpdateBinding.inflate(android.view.LayoutInflater.from(context))
        dialog = AlertDialog.Builder(context)
            .setView(binding.root)
            .setCancelable(false)
            .create()
        dialog.show()

        lifecycleScope.launch {
            val update = runCatching { repository.getAppUpdate() }.getOrNull()
            if (update == null || update.versionCode <= BuildConfig.VERSION_CODE || update.apkUrl.isEmpty()) {
                showUpToDate()
            } else {
                showUpdateAvailable(update)
            }
        }
    }

    private fun showUpToDate() {
        binding.groupChecking.visibility = View.GONE
        binding.groupResult.visibility = View.VISIBLE
        binding.tvUpdateTitle.text = "You're up to date"
        binding.tvUpdateMessage.text = "You're already on the latest version (v${BuildConfig.VERSION_NAME})."
        binding.btnSecondary.visibility = View.GONE
        binding.btnPrimary.text = "OK"
        binding.btnPrimary.setOnClickListener { dialog.dismiss() }
        dialog.setCancelable(true)
    }

    private fun showUpdateAvailable(update: AppUpdateInfo) {
        binding.groupChecking.visibility = View.GONE
        binding.groupResult.visibility = View.VISIBLE
        dialog.setCancelable(true)

        if (update.iconUrl.isNotEmpty()) {
            Glide.with(context).load(update.iconUrl).placeholder(R.drawable.ic_launcher).into(binding.ivUpdateIcon)
        }

        binding.tvUpdateTitle.text = "Update Available"
        binding.tvUpdateMessage.text = "Version ${update.versionName} is ready to download."

        if (update.whatsNew.isNotBlank()) {
            binding.tvWhatsNewLabel.visibility = View.VISIBLE
            binding.tvWhatsNew.visibility = View.VISIBLE
            binding.tvWhatsNew.text = update.whatsNew
        }

        binding.btnSecondary.text = "Later"
        binding.btnSecondary.setOnClickListener { dialog.dismiss() }
        binding.btnPrimary.text = "Update Now"
        binding.btnPrimary.setOnClickListener { startDownload(update) }
    }

    private fun startDownload(update: AppUpdateInfo) {
        dialog.setCancelable(false)
        binding.btnPrimary.isEnabled = false
        binding.btnSecondary.isEnabled = false
        binding.groupDownloadProgress.visibility = View.VISIBLE

        downloadHelper.startDownload(update.apkUrl, "${context.getString(R.string.app_name)} Update") { id ->
            activeDownloadId = id
            downloadHelper.registerCompletionReceiver(id) { uri: Uri? ->
                if (context is android.app.Activity) {
                    context.runOnUiThread { onDownloadComplete(uri) }
                } else {
                    onDownloadComplete(uri)
                }
            }
        }
    }

    private fun onDownloadComplete(uri: Uri?) {
        binding.groupDownloadProgress.visibility = View.GONE
        if (uri != null) {
            binding.tvDownloadStatus.text = "Installing…"
            downloadHelper.installApk(uri)
            dialog.dismiss()
        } else {
            Toast.makeText(context, "Update download failed", Toast.LENGTH_SHORT).show()
            binding.btnPrimary.isEnabled = true
            binding.btnSecondary.isEnabled = true
            dialog.setCancelable(true)
        }
    }
}
