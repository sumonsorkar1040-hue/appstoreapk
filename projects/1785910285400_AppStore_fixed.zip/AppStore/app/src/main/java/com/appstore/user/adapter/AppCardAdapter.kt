package com.appstore.user.adapter

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.appstore.user.data.model.AppModel
import com.appstore.user.databinding.ItemAppCardBinding

class AppCardAdapter(private val onClick: (AppModel) -> Unit) :
    ListAdapter<AppModel, AppCardAdapter.CardViewHolder>(DIFF) {

    inner class CardViewHolder(val binding: ItemAppCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val binding = ItemAppCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CardViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        val app = getItem(position)
        holder.binding.tvName.text = app.name
        holder.binding.tvRating.text = String.format("%.1f", app.rating)
        holder.binding.shimmerIcon.showShimmer(true)
        Glide.with(holder.itemView.context)
            .load(app.iconUrl)
            .centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade())
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerIcon.hideShimmer()
                    return false
                }
                override fun onResourceReady(resource: Drawable, model: Any, target: Target<Drawable>?, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerIcon.hideShimmer()
                    return false
                }
            })
            .into(holder.binding.ivIcon)
        holder.itemView.setOnClickListener { onClick(app) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<AppModel>() {
            override fun areItemsTheSame(oldItem: AppModel, newItem: AppModel) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: AppModel, newItem: AppModel) = oldItem == newItem
        }
    }
}
