package com.appstore.user.adapter

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.appstore.user.data.model.Banner
import com.appstore.user.databinding.ItemBannerBinding

class BannerAdapter(private val onClick: (Banner) -> Unit) :
    RecyclerView.Adapter<BannerAdapter.BannerViewHolder>() {

    private var banners: List<Banner> = emptyList()

    fun submitList(list: List<Banner>) {
        banners = list
        notifyDataSetChanged()
    }

    inner class BannerViewHolder(val binding: ItemBannerBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BannerViewHolder {
        val binding = ItemBannerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BannerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BannerViewHolder, position: Int) {
        val banner = banners[position]
        holder.binding.shimmerBanner.showShimmer(true)
        Glide.with(holder.itemView.context)
            .load(banner.imageUrl)
            .centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade())
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerBanner.hideShimmer()
                    return false
                }
                override fun onResourceReady(resource: Drawable, model: Any, target: Target<Drawable>?, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerBanner.hideShimmer()
                    return false
                }
            })
            .into(holder.binding.ivBanner)
        holder.itemView.setOnClickListener { onClick(banner) }
    }

    override fun getItemCount() = banners.size
}
