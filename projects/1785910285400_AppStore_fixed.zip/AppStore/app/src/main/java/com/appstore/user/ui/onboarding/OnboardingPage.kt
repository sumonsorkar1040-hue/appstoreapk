package com.appstore.user.ui.onboarding

data class OnboardingPage(
    val title: String,
    val description: String,
    val imageRes: Int
)
