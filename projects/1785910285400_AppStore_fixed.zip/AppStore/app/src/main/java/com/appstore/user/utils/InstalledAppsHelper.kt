package com.appstore.user.utils

import android.content.Context
import android.content.pm.PackageManager
import com.appstore.user.data.model.AppModel

object InstalledAppsHelper {

    fun isInstalled(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun installedVersion(context: Context, packageName: String): String? {
        return try {
            context.packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    /** From the full catalog, returns only apps that are installed AND whose store version differs. */
    fun findUpdatable(context: Context, allApps: List<AppModel>): List<AppModel> {
        return allApps.filter { app ->
            val installed = installedVersion(context, app.packageName)
            installed != null && installed != app.version
        }
    }
}
