package com.appstore.user.data.model

data class Banner(
    var id: String = "",
    var imageUrl: String = "",
    var title: String = "",
    var linkAppId: String = "",
    var sortOrder: Int = 0
)
