package com.appstore.user.data.model

data class NotificationItem(
    var id: String = "",
    var title: String = "",
    var body: String = "",
    var type: String = "", // new_app | update | offer | announcement
    var appId: String = "",
    var imageUrl: String = "",
    var timestamp: Long = 0,
    var isRead: Boolean = false
)
