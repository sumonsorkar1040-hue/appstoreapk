package com.appstore.user.data.repository

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.model.AppUpdateInfo
import com.appstore.user.data.model.Banner
import com.appstore.user.data.model.Category
import com.appstore.user.data.model.Feedback
import com.appstore.user.data.model.NotificationItem
import com.appstore.user.data.model.Review
import com.appstore.user.data.model.UserModel
import com.appstore.user.utils.Constants
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Single source of truth for all data reads used by the user-facing app.
 *
 * Uses Cloud Firestore — the SAME database the Admin Panel (AppStoreAdmin)
 * writes to via its FirebaseRepository. Only apps with status == "PUBLISHED"
 * are shown to end users; DRAFT/PENDING/REJECTED/HIDDEN apps stay invisible
 * here, matching the workflow in the admin app's Requests screen.
 *
 * Field names below (appName, apkDownloadUrl, screenshotUrls, isEditorsChoice,
 * isVerified, downloads, reviewCount, status, ...) are intentionally the exact
 * Firestore field names used by AppStoreAdmin's AppModel — they are mapped
 * here onto this app's own AppModel shape so the rest of the user app (UI,
 * adapters, view models) doesn't need to change at all.
 */
class AppRepository {

    private val db = FirebaseFirestore.getInstance()

    private val appsRef get() = db.collection(Constants.COLLECTION_APPS)

    private val statusPublished = "PUBLISHED"

    // ---------- Apps ----------

    /** One-shot fetch of every published app. */
    suspend fun getAllApps(): List<AppModel> = try {
        appsRef.whereEqualTo("status", statusPublished).get().await()
            .documents.mapNotNull { mapAppDoc(it) }
    } catch (e: Exception) {
        emptyList()
    }

    /** Client-side search across name/developer/category. */
    suspend fun searchApps(query: String): List<AppModel> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        return getAllApps().filter {
            it.name.lowercase().contains(q) ||
                it.developer.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }
    }

    suspend fun getTrendingSearchKeywords(): List<String> = try {
        db.collection(Constants.COLLECTION_SEARCH_KEYWORDS)
            .orderBy("count", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(10)
            .get().await()
            .documents.map { it.id }
    } catch (e: Exception) {
        emptyList()
    }

    /** Pushes a new review and recomputes the app's aggregate rating/reviewCount. */
    suspend fun submitReview(appId: String, review: Review): Result<Unit> = runCatching {
        val ref = db.collection(Constants.COLLECTION_REVIEWS).document()
        val toSave = review.copy(id = ref.id, appId = appId)
        ref.set(toSave).await()
        recomputeRating(appId)
    }

    /** One-shot fetch of the privacy policy text set by the admin. */
    suspend fun getPrivacyPolicy(): String = try {
        val doc = db.collection(Constants.COLLECTION_SETTINGS).document(Constants.SETTINGS_DOC_CONFIG).get().await()
        doc.getString("privacyPolicy").orEmpty()
    } catch (e: Exception) {
        ""
    }

    /** One-shot fetch of the App Store app's own latest-version info. */
    suspend fun getAppUpdate(): AppUpdateInfo? = try {
        val doc = db.collection(Constants.COLLECTION_SETTINGS).document(Constants.SETTINGS_DOC_CONFIG).get().await()
        @Suppress("UNCHECKED_CAST")
        val map = doc.get("appUpdate") as? Map<String, Any?> ?: return null
        AppUpdateInfo(
            versionCode = (map["versionCode"] as? Number)?.toInt() ?: 0,
            versionName = map["versionName"] as? String ?: "",
            iconUrl = map["iconUrl"] as? String ?: "",
            whatsNew = map["whatsNew"] as? String ?: "",
            apkUrl = map["apkUrl"] as? String ?: "",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: 0
        )
    } catch (e: Exception) {
        null
    }

    /** Sends a Help & Feedback message from the current user. */
    suspend fun submitFeedback(feedback: Feedback): Result<Unit> = runCatching {
        val ref = db.collection(Constants.COLLECTION_FEEDBACK).document()
        ref.set(feedback.copy(id = ref.id)).await()
    }

    private fun recomputeRating(appId: String) {
        db.collection(Constants.COLLECTION_REVIEWS).whereEqualTo("appId", appId).get()
            .addOnSuccessListener { snapshot ->
                val ratings = snapshot.documents.mapNotNull { it.toObject(Review::class.java)?.rating }
                if (ratings.isEmpty()) return@addOnSuccessListener
                val avg = ratings.average()
                appsRef.document(appId).update(
                    mapOf(
                        "rating" to avg,
                        "reviewCount" to ratings.size.toLong()
                    )
                )
            }
    }

    suspend fun getUserModel(uid: String): UserModel? = try {
        db.collection(Constants.COLLECTION_USERS).document(uid).get().await()
            .toObject(UserModel::class.java)
    } catch (e: Exception) {
        null
    }

    fun observeUserModel(uid: String): Flow<UserModel?> = callbackFlow {
        val ref = db.collection(Constants.COLLECTION_USERS).document(uid)
        val registration = ref.addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            trySend(snapshot?.toObject(UserModel::class.java))
        }
        awaitClose { registration.remove() }
    }

    fun setWishlisted(uid: String, appId: String, wishlisted: Boolean) {
        val ref = db.collection(Constants.COLLECTION_USERS).document(uid)
        if (wishlisted) {
            ref.update("wishlist.$appId", true)
                .addOnFailureListener { ref.set(mapOf("wishlist" to mapOf(appId to true)), com.google.firebase.firestore.SetOptions.merge()) }
        } else {
            ref.update("wishlist.$appId", com.google.firebase.firestore.FieldValue.delete())
        }
    }

    fun setFavorited(uid: String, appId: String, favorited: Boolean) {
        val ref = db.collection(Constants.COLLECTION_USERS).document(uid)
        if (favorited) {
            ref.update("favorites.$appId", true)
                .addOnFailureListener { ref.set(mapOf("favorites" to mapOf(appId to true)), com.google.firebase.firestore.SetOptions.merge()) }
        } else {
            ref.update("favorites.$appId", com.google.firebase.firestore.FieldValue.delete())
        }
    }

    suspend fun getAppsByIds(ids: List<String>): List<AppModel> {
        if (ids.isEmpty()) return emptyList()
        return ids.mapNotNull { getAppById(it) }
    }

    fun observeNotifications(uid: String): Flow<List<NotificationItem>> = callbackFlow {
        val ref = db.collection(Constants.COLLECTION_NOTIFICATIONS).document(uid).collection("items")
        val registration = ref.addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            val list = snapshot?.documents
                ?.mapNotNull { it.toObject(NotificationItem::class.java)?.copy(id = it.id) }
                ?.sortedByDescending { it.timestamp }
                .orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    fun markNotificationRead(uid: String, notificationId: String) {
        db.collection(Constants.COLLECTION_NOTIFICATIONS).document(uid).collection("items")
            .document(notificationId).update("isRead", true)
    }

    /** Fetches a home-screen section (Featured, Trending, etc). Top Charts / New
     *  Releases are derived client-side (sorted by downloads / createdAt) since
     *  the admin panel has no toggle for those two — everything else uses the
     *  matching boolean flag the admin panel actually exposes. */
    suspend fun getSection(nodeName: String, limit: Int = 15): List<AppModel> = try {
        when (nodeName) {
            Constants.NODE_TOP_CHARTS ->
                getAllApps().sortedByDescending { it.downloadsCount }.take(limit)
            Constants.NODE_NEW_RELEASES ->
                getAllApps().sortedByDescending { it.createdAt }.take(limit)
            else -> {
                val field = nodeMapToField(nodeName)
                appsRef.whereEqualTo("status", statusPublished)
                    .whereEqualTo(field, true)
                    .limit(limit.toLong())
                    .get().await()
                    .documents.mapNotNull { mapAppDoc(it) }
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun nodeMapToField(nodeName: String): String = when (nodeName) {
        Constants.NODE_FEATURED -> "isFeatured"
        Constants.NODE_TRENDING -> "isTrending"
        Constants.NODE_EDITOR_CHOICE -> "isEditorsChoice"
        else -> "isFeatured"
    }

    suspend fun getAppsByCategory(category: String): List<AppModel> {
        if (category == Constants.CATEGORY_FOR_YOU) {
            // "For You" isn't a real category — surface everything, highest rated first.
            return getAllApps().sortedByDescending { it.rating }
        }
        return try {
            appsRef.whereEqualTo("status", statusPublished)
                .whereEqualTo("category", category)
                .get().await()
                .documents.mapNotNull { mapAppDoc(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAppById(appId: String): AppModel? = try {
        mapAppDoc(appsRef.document(appId).get().await())
    } catch (e: Exception) {
        null
    }

    suspend fun getCategories(gamesOnly: Boolean = false): List<Category> = try {
        val all = db.collection(Constants.COLLECTION_CATEGORIES).get().await()
            .documents
            .filter { it.getBoolean("isHidden") != true } // admin's "hide category" toggle
            .mapNotNull { mapCategoryDoc(it) }
            .sortedBy { it.sortOrder }
        if (gamesOnly) all.filter { it.isGameCategory } else all
    } catch (e: Exception) {
        emptyList()
    }

    /** Unlimited, admin-created custom Home sections (e.g. "New Releases",
     *  "Top Charts", or any other name) — separate from the fixed
     *  Featured/Trending/Editor's Choice/Featured Games sections above. */
    suspend fun getHomeSections(): List<com.appstore.user.data.model.HomeSection> = try {
        db.collection(Constants.COLLECTION_HOME_SECTIONS).get().await()
            .documents
            .filter { it.getBoolean("isHidden") != true }
            .mapNotNull { mapHomeSectionDoc(it) }
            .sortedBy { it.sortOrder }
    } catch (e: Exception) {
        emptyList()
    }

    /** Apps the admin explicitly added to the given custom Home section at publish time. */
    suspend fun getAppsByHomeSection(sectionId: String, limit: Int = 30): List<AppModel> = try {
        appsRef.whereEqualTo("status", statusPublished)
            .whereArrayContains(Constants.FIELD_HOME_SECTION_IDS, sectionId)
            .limit(limit.toLong())
            .get().await()
            .documents.mapNotNull { mapAppDoc(it) }
    } catch (e: Exception) {
        emptyList()
    }

    suspend fun getBanners(): List<Banner> = try {
        db.collection(Constants.COLLECTION_BANNERS).get().await()
            .documents
            .filter { it.getBoolean("isEnabled") != false } // admin's "enable banner" toggle
            .mapNotNull { mapBannerDoc(it) }
            .sortedBy { it.sortOrder }
    } catch (e: Exception) {
        emptyList()
    }

    /** Live-updating reviews list for an app details screen. */
    fun observeReviews(appId: String): Flow<List<Review>> = callbackFlow {
        val ref = db.collection(Constants.COLLECTION_REVIEWS).whereEqualTo("appId", appId)
        val registration = ref.addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            val list = snapshot?.documents
                ?.mapNotNull { it.toObject(Review::class.java)?.copy(id = it.id) }
                ?.sortedByDescending { it.timestamp }
                .orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    /** Maintenance mode / force-update are stored by the admin app in local,
     *  encrypted, admin-device-only storage today — they aren't published
     *  anywhere the user app can read yet, so this stays "off" until the
     *  admin panel is updated to publish them to Firestore. Wired to the
     *  shared settings doc so it starts working the moment that's added. */
    suspend fun isMaintenanceModeOn(): Boolean = try {
        db.collection(Constants.COLLECTION_SETTINGS).document(Constants.SETTINGS_DOC_CONFIG)
            .get().await().getBoolean("maintenanceMode") ?: false
    } catch (e: Exception) {
        false
    }

    fun incrementDownloadCount(appId: String) {
        appsRef.document(appId).update("downloads", com.google.firebase.firestore.FieldValue.increment(1))
    }

    // ---------- Mapping: Firestore docs (Admin Panel schema) -> user-app models ----------

    private fun mapAppDoc(doc: DocumentSnapshot): AppModel? {
        if (!doc.exists()) return null
        val data = doc.data ?: return null
        val category = data["category"] as? String ?: ""
        return AppModel(
            id = doc.id,
            name = data["appName"] as? String ?: "",
            developer = data["developerName"] as? String ?: "",
            developerVerified = data["isVerified"] as? Boolean ?: false,
            iconUrl = data["iconUrl"] as? String ?: "",
            screenshots = (data["screenshotUrls"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            promoVideoUrl = "",
            packageName = data["packageName"] as? String ?: "",
            category = category,
            isGame = category.equals(Constants.GAMES_CATEGORY_NAME, ignoreCase = true),
            shortDescription = (data["description"] as? String)?.take(150) ?: "",
            description = data["description"] as? String ?: "",
            whatsNew = data["whatsNew"] as? String ?: "",
            version = data["versionName"] as? String ?: "",
            apkUrl = data["apkDownloadUrl"] as? String ?: "",
            fileSizeMb = (data["apkSizeMb"] as? Number)?.toDouble() ?: 0.0,
            minAndroidVersion = data["minAndroidVersion"] as? String ?: "",
            ageRating = "",
            downloadsCount = (data["downloads"] as? Number)?.toLong() ?: 0,
            rating = (data["rating"] as? Number)?.toDouble() ?: 0.0,
            ratingCount = (data["reviewCount"] as? Number)?.toLong() ?: 0,
            permissions = emptyList(),
            dataSafetyNotes = "",
            privacyPolicyUrl = data["privacyPolicyUrl"] as? String ?: "",
            isFeatured = data["isFeatured"] as? Boolean ?: false,
            isEditorChoice = data["isEditorsChoice"] as? Boolean ?: false,
            isTrending = data["isTrending"] as? Boolean ?: false,
            isTopChart = false,
            isNewRelease = false,
            createdAt = (data["createdAt"] as? Number)?.toLong() ?: 0,
            updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: 0,
            homeSectionIds = (data[Constants.FIELD_HOME_SECTION_IDS] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        )
    }

    private fun mapHomeSectionDoc(doc: DocumentSnapshot): com.appstore.user.data.model.HomeSection? {
        if (!doc.exists()) return null
        val data = doc.data ?: return null
        return com.appstore.user.data.model.HomeSection(
            id = doc.id,
            name = data["name"] as? String ?: "",
            iconUrl = data["iconUrl"] as? String ?: "",
            isHidden = data["isHidden"] as? Boolean ?: false,
            sortOrder = (data["sortOrder"] as? Number)?.toInt() ?: 0
        )
    }

    private fun mapCategoryDoc(doc: DocumentSnapshot): Category? {
        if (!doc.exists()) return null
        val data = doc.data ?: return null
        val name = data["name"] as? String ?: ""
        return Category(
            id = doc.id,
            name = name,
            iconUrl = data["iconUrl"] as? String ?: "",
            isGameCategory = name.equals(Constants.GAMES_CATEGORY_NAME, ignoreCase = true),
            sortOrder = (data["sortOrder"] as? Number)?.toInt() ?: 0
        )
    }

    private fun mapBannerDoc(doc: DocumentSnapshot): Banner? {
        if (!doc.exists()) return null
        val data = doc.data ?: return null
        return Banner(
            id = doc.id,
            imageUrl = data["imageUrl"] as? String ?: "",
            title = data["title"] as? String ?: "",
            linkAppId = data["buttonLink"] as? String ?: "",
            sortOrder = (data["sortOrder"] as? Number)?.toInt() ?: 0
        )
    }
}
