package com.appstore.user.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.appstore.user.data.model.PublishRequest
import com.appstore.user.utils.Constants
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Handles everything the user-facing "Upload App" screen needs to submit a
 * new app for admin review:
 *  - uploads images (icon, screenshots, feature graphic) to imgbb
 *  - uploads the APK file straight to a GitHub repository via the
 *    Contents API (using a personal access token)
 *  - writes the resulting listing straight into Cloud Firestore's "apps"
 *    collection with status = "PENDING", using the Admin Panel's own field
 *    names, so it shows up immediately in the admin app's Requests screen
 *    (which just queries apps where status == PENDING) for approval.
 */
class PublishRepository {

    private val db = FirebaseFirestore.getInstance()

    /** Uploads a single image (icon / screenshot / feature graphic) to imgbb and returns its URL. */
    suspend fun uploadImageToImgbb(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(Exception("Unable to read image"))
            val bytes = inputStream.readBytes()
            inputStream.close()
            val base64Image = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val url = URL("${Constants.IMGBB_UPLOAD_URL}?key=${Constants.IMGBB_API_KEY}")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 60000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

            val postData = "image=${URLEncoder.encode(base64Image, "UTF-8")}"
            DataOutputStream(conn.outputStream).use { it.writeBytes(postData) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
                return@withContext Result.failure(Exception("imgbb upload failed ($code): $err"))
            }

            val response = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(response)
            val imageUrl = json.getJSONObject("data").getString("url")
            Result.success(imageUrl)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Uploads the selected APK file directly to a GitHub repository using the
     * Contents API (PUT /repos/{owner}/{repo}/contents/{path}) and returns a
     * public raw download URL for the committed file.
     */
    suspend fun uploadApkToGithub(
        context: Context,
        uri: Uri,
        fileName: String
    ): Result<Pair<String, Double>> = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(Exception("Unable to read APK"))
            val bytes = inputStream.readBytes()
            inputStream.close()
            val fileSizeMb = bytes.size / (1024.0 * 1024.0)
            val base64Content = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val path = "${Constants.GITHUB_APK_FOLDER}/${System.currentTimeMillis()}_$safeName"

            val apiUrl = URL(
                "${Constants.GITHUB_API_BASE}/repos/${Constants.GITHUB_OWNER}/${Constants.GITHUB_REPO}/contents/$path"
            )
            val conn = apiUrl.openConnection() as HttpURLConnection
            conn.requestMethod = "PUT"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.setRequestProperty("Authorization", "Bearer ${Constants.GITHUB_TOKEN}")
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("Content-Type", "application/json")

            val body = JSONObject().apply {
                put("message", "Upload $safeName via Upload App")
                put("content", base64Content)
                put("branch", Constants.GITHUB_BRANCH)
            }

            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
                return@withContext Result.failure(Exception("GitHub upload failed ($code): $err"))
            }

            val response = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(response)
            val downloadUrl = json.getJSONObject("content").optString(
                "download_url",
                "https://raw.githubusercontent.com/${Constants.GITHUB_OWNER}/${Constants.GITHUB_REPO}/${Constants.GITHUB_BRANCH}/$path"
            )
            Result.success(downloadUrl to fileSizeMb)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Writes the completed submission into Firestore's "apps" collection with
     * status = "PENDING", using the exact field names AppStoreAdmin's
     * AppModel/FirebaseRepository expect (appName, apkDownloadUrl,
     * screenshotUrls, versionCode as Int, ...). Extra fields not present in
     * the admin's Kotlin model (submittedByUid/Name/Email) are also written —
     * Firestore is schemaless, so the admin app simply ignores fields it
     * doesn't know about when it deserializes the same document — and are
     * used here to power the Developer Dashboard's "my submissions" list.
     */
    suspend fun submitPublishRequest(request: PublishRequest): Result<Unit> = runCatching {
        val ref = db.collection(Constants.COLLECTION_APPS).document()
        val now = System.currentTimeMillis()
        val doc = mapOf(
            "id" to ref.id,
            "appName" to request.appName,
            "packageName" to request.packageName,
            "versionName" to request.versionName,
            "versionCode" to (request.versionCode.toIntOrNull() ?: 1),
            "apkSizeMb" to request.fileSizeMb,
            "developerName" to request.developerName,
            "developerWebsite" to "",
            "supportEmail" to request.ownerEmail,
            "privacyPolicyUrl" to request.privacyPolicyUrl,
            "description" to request.description,
            "whatsNew" to request.whatsNew,
            "category" to request.category,
            "subCategory" to "",
            "minAndroidVersion" to "",
            "targetAndroidVersion" to "",
            "iconUrl" to request.iconUrl,
            "bannerUrl" to request.featureGraphicUrl,
            "screenshotUrls" to request.screenshots,
            "apkDownloadUrl" to request.apkUrl,
            "status" to "PENDING",
            "isFeatured" to false,
            "isTrending" to false,
            "isEditorsChoice" to false,
            "isVerified" to false,
            "downloads" to 0L,
            "rating" to 0.0,
            "reviewCount" to 0L,
            "createdAt" to now,
            "updatedAt" to now,
            // extra fields (ignored by the admin app's typed model, used by this app only)
            "submittedByUid" to request.ownerUid,
            "submittedByName" to request.ownerName,
            "submittedByEmail" to request.ownerEmail,
            "tags" to request.tags
        )
        ref.set(doc).await()
    }

    /** Live list of the current user's own submitted apps, newest first, for the Developer Dashboard. */
    fun observeMyPublishRequests(uid: String): Flow<List<PublishRequest>> = callbackFlow {
        val ref = db.collection(Constants.COLLECTION_APPS).whereEqualTo("submittedByUid", uid)
        val registration = ref.addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            val list = snapshot?.documents
                ?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    PublishRequest(
                        id = doc.id,
                        ownerUid = data["submittedByUid"] as? String ?: uid,
                        ownerName = data["submittedByName"] as? String ?: "",
                        ownerEmail = data["submittedByEmail"] as? String ?: "",
                        appName = data["appName"] as? String ?: "",
                        developerName = data["developerName"] as? String ?: "",
                        category = data["category"] as? String ?: "",
                        packageName = data["packageName"] as? String ?: "",
                        versionName = data["versionName"] as? String ?: "",
                        versionCode = (data["versionCode"] as? Number)?.toInt()?.toString() ?: "",
                        description = data["description"] as? String ?: "",
                        whatsNew = data["whatsNew"] as? String ?: "",
                        iconUrl = data["iconUrl"] as? String ?: "",
                        screenshots = (data["screenshotUrls"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        featureGraphicUrl = data["bannerUrl"] as? String ?: "",
                        apkUrl = data["apkDownloadUrl"] as? String ?: "",
                        fileSizeMb = (data["apkSizeMb"] as? Number)?.toDouble() ?: 0.0,
                        privacyPolicyUrl = data["privacyPolicyUrl"] as? String ?: "",
                        // Admin stores status as "PENDING"/"PUBLISHED"/"REJECTED"/... — the
                        // Developer Dashboard UI expects lowercase, so it's normalized here.
                        status = (data["status"] as? String ?: "PENDING").lowercase(),
                        submittedAt = (data["createdAt"] as? Number)?.toLong() ?: 0,
                        reviewedAt = (data["updatedAt"] as? Number)?.toLong() ?: 0
                    )
                }
                ?.sortedByDescending { it.submittedAt }
                .orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }
}
