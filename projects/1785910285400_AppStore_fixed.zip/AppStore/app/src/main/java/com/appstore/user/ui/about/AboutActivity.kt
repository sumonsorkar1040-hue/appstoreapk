package com.appstore.user.ui.about

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import com.appstore.user.BuildConfig
import com.appstore.user.databinding.ActivityAboutBinding
import java.util.Calendar

/**
 * "About" screen, reachable from Profile -> About.
 *
 * Shows the app logo, name, version, a short description, and the
 * copyright line.
 */
class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the top bar. Pad the root container (not the
        // top bar itself) by the top inset, so the top bar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        val appName = getString(com.appstore.user.R.string.app_name)
        val versionLabel = "Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
        val year = Calendar.getInstance().get(Calendar.YEAR)

        binding.tvAppName.text = appName
        binding.tvVersion.text = versionLabel
        binding.tvRowAppName.text = appName
        binding.tvRowVersion.text = versionLabel
        binding.tvCopyright.text = "© $year $appName. All rights reserved."

        binding.ivBack.setOnClickListener { finish() }
    }
}
