package com.appstore.user.ui.detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.R
import com.appstore.user.adapter.AppCardAdapter
import com.appstore.user.adapter.ReviewAdapter
import com.appstore.user.adapter.ScreenshotAdapter
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityAppDetailBinding
import com.appstore.user.ui.review.WriteReviewActivity
import com.appstore.user.utils.Constants
import com.appstore.user.utils.DownloadManagerHelper
import com.appstore.user.utils.InstalledAppsHelper
import kotlinx.coroutines.launch

class AppDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppDetailBinding
    private val viewModel: AppDetailViewModel by lazy {
        androidx.lifecycle.ViewModelProvider(this)[AppDetailViewModel::class.java]
    }
    private val repository = AppRepository()
    private lateinit var downloadHelper: DownloadManagerHelper
    private var activeDownloadId: Long = -1
    private var currentApp: AppModel? = null
    private var isWishlisted = false
    private var isFavorited = false

    private val reviewAdapter = ReviewAdapter()
    private val similarAdapter = AppCardAdapter { app -> reopenWith(app.id) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(binding.appBar) { view, insets ->
            val statusBarInset = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            view.updatePadding(top = statusBarInset.top)
            insets
        }
        downloadHelper = DownloadManagerHelper(this)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvReviews.layoutManager = LinearLayoutManager(this)
        binding.rvReviews.adapter = reviewAdapter
        binding.rvSimilarApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvSimilarApps.adapter = similarAdapter

        val appId = intent.getStringExtra(Constants.EXTRA_APP_ID).orEmpty()
        if (appId.isEmpty()) { finish(); return }

        viewModel.app.observe(this) { app ->
            if (app != null) bindApp(app)
        }
        viewModel.similarApps.observe(this) { similarAdapter.submitList(it) }
        viewModel.reviews.observe(this) { reviewAdapter.submitList(it) }
        viewModel.load(appId)

        observeWishlistState(appId)

        binding.ivWishlist.setOnClickListener { toggleWishlist(appId) }
        binding.ivFavorite.setOnClickListener { toggleFavorite(appId) }
        binding.ivShare.setOnClickListener { shareApp() }
        binding.ratingWidget.setOnRatingBarChangeListener { _, rating, fromUser ->
            if (fromUser) openWriteReview(preset = rating)
        }
        binding.btnWriteReview.setOnClickListener { openWriteReview(preset = 0f) }
    }

    private fun openWriteReview(preset: Float) {
        val app = currentApp ?: return
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(this, "Please log in to leave a review", Toast.LENGTH_SHORT).show()
            binding.ratingWidget.rating = 0f
            return
        }
        val intent = Intent(this, WriteReviewActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, app.id)
        intent.putExtra(Constants.EXTRA_SECTION_TITLE, app.name)
        if (preset > 0f) intent.putExtra(Constants.EXTRA_PRESET_RATING, preset)
        startActivity(intent)
        binding.ratingWidget.rating = 0f
    }

    private fun observeWishlistState(appId: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        repository.observeUserModel(uid).let { flow ->
            lifecycleScope.launch {
                flow.collect { userModel ->
                    isWishlisted = userModel?.wishlist?.containsKey(appId) == true
                    isFavorited = userModel?.favorites?.containsKey(appId) == true
                    binding.ivWishlist.setImageResource(
                        if (isWishlisted) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
                    )
                    binding.ivFavorite.setImageResource(
                        if (isFavorited) R.drawable.ic_bookmark_filled else R.drawable.ic_bookmark_outline
                    )
                }
            }
        }
    }

    private fun toggleWishlist(appId: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            Toast.makeText(this, "Please log in to save apps", Toast.LENGTH_SHORT).show()
            return
        }
        repository.setWishlisted(uid, appId, !isWishlisted)
    }

    private fun toggleFavorite(appId: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            Toast.makeText(this, "Please log in to save apps", Toast.LENGTH_SHORT).show()
            return
        }
        repository.setFavorited(uid, appId, !isFavorited)
    }

    private fun shareApp() {
        val app = currentApp ?: return
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Check out ${app.name} on App Store!")
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }

    private fun bindApp(app: AppModel) {
        currentApp = app
        binding.tvName.text = app.name
        binding.tvDeveloper.text = if (app.developerVerified) "${app.developer} ✓" else app.developer
        binding.tvRating.text = String.format("%.1f★", app.rating)
        binding.tvDownloads.text = formatCount(app.downloadsCount)
        binding.tvSize.text = String.format("%.2f MB", app.fileSizeMb)
        binding.tvDescription.text = app.description
        binding.tvWhatsNew.text = app.whatsNew.ifEmpty { "No update notes yet." }

        com.bumptech.glide.Glide.with(this).load(app.iconUrl).centerCrop().into(binding.ivIcon)
        binding.rvScreenshots.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvScreenshots.adapter = ScreenshotAdapter(app.screenshots)

        updateActionButton(app)
        binding.btnAction.setOnClickListener { onActionClicked(app) }
    }

    private fun updateActionButton(app: AppModel) {
        val installedVersion = InstalledAppsHelper.installedVersion(this, app.packageName)
        binding.btnAction.text = when {
            installedVersion == null -> getString(R.string.install)
            installedVersion != app.version -> getString(R.string.update)
            else -> getString(R.string.open)
        }
    }

    private fun onActionClicked(app: AppModel) {
        val installedVersion = InstalledAppsHelper.installedVersion(this, app.packageName)
        if (installedVersion == app.version && installedVersion != null) {
            val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) startActivity(launchIntent)
            return
        }
        startDownload(app)
    }

    private fun startDownload(app: AppModel) {
        if (app.apkUrl.isEmpty()) {
            Toast.makeText(this, "APK not available", Toast.LENGTH_SHORT).show()
            return
        }
        binding.waveProgress.progress = 0
        morphButtonToProgress()

        downloadHelper.startDownload(app.apkUrl, app.name) { id ->
            activeDownloadId = id
            viewModel.registerDownload(app.id)
            observeDownloadProgress(id)
            observeDownloadCompletion(id)
        }

        binding.ivCancelDownload.setOnClickListener {
            downloadHelper.cancelDownload(activeDownloadId)
            morphProgressToButton()
        }
    }

    /** Shrinks the Install button away and pops in the percentage progress pill in its place. */
    private fun morphButtonToProgress() {
        binding.btnAction.animate()
            .scaleX(0.85f).scaleY(0.85f).alpha(0f)
            .setDuration(140)
            .withEndAction {
                binding.btnAction.visibility = View.GONE
                binding.btnAction.scaleX = 1f
                binding.btnAction.scaleY = 1f
                binding.btnAction.alpha = 1f

                binding.downloadProgressGroup.apply {
                    scaleX = 0.85f
                    scaleY = 0.85f
                    alpha = 0f
                    visibility = View.VISIBLE
                    animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
                }
                binding.waveProgress.start()
            }.start()
    }

    /** Reverses the morph: progress pill shrinks away and the Install/Open button pops back in. */
    private fun morphProgressToButton() {
        binding.waveProgress.stop()
        binding.downloadProgressGroup.animate()
            .scaleX(0.85f).scaleY(0.85f).alpha(0f)
            .setDuration(140)
            .withEndAction {
                binding.downloadProgressGroup.visibility = View.GONE
                binding.downloadProgressGroup.scaleX = 1f
                binding.downloadProgressGroup.scaleY = 1f
                binding.downloadProgressGroup.alpha = 1f

                binding.btnAction.apply {
                    scaleX = 0.85f
                    scaleY = 0.85f
                    alpha = 0f
                    visibility = View.VISIBLE
                    animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
                }
            }.start()
    }

    /** Feeds real DownloadManager progress into the wave view. */
    private fun observeDownloadProgress(downloadId: Long) {
        downloadHelper.trackProgress(downloadId) { percent ->
            runOnUiThread {
                binding.waveProgress.progress = percent
            }
        }
    }

    private fun observeDownloadCompletion(downloadId: Long) {
        downloadHelper.registerCompletionReceiver(downloadId) { uri: Uri? ->
            runOnUiThread {
                binding.waveProgress.progress = 100
                morphProgressToButton()
                if (uri != null) {
                    // Auto-launch the installer as soon as the APK finishes downloading.
                    downloadHelper.installApk(uri)
                } else {
                    Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        downloadHelper.stopTrackingProgress()
        binding.waveProgress.stop()
    }

    private fun reopenWith(appId: String) {
        val intent = intent
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        finish()
        startActivity(intent)
    }

    private fun formatCount(count: Long): String = when {
        count >= 1_000_000_000 -> String.format("%.1fB+", count / 1_000_000_000.0)
        count >= 1_000_000 -> String.format("%.1fM+", count / 1_000_000.0)
        count >= 1_000 -> String.format("%.1fK+", count / 1_000.0)
        else -> count.toString()
    }
}
