package com.appstore.user.ui.main.profile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.data.repository.PublishRepository
import com.appstore.user.databinding.FragmentProfileBinding
import com.appstore.user.ui.auth.LoginActivity
import com.appstore.user.ui.main.MainActivity
import com.appstore.user.utils.Constants
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private val authRepository = AuthRepository()
    private val publishRepository = PublishRepository()

    private val pickProfilePhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) uploadProfilePhoto(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        bindUser()

        binding.ivProfile.setOnClickListener { pickProfilePhoto.launch("image/*") }
        binding.ivPickProfilePhoto.setOnClickListener { pickProfilePhoto.launch("image/*") }

        binding.rowWishlistCard.setOnClickListener { openCollections(0) }
        binding.rowUploadApp.setOnClickListener {
            if (authRepository.isGuest) {
                showLoginRequiredDialog()
            } else {
                startActivity(Intent(requireContext(), com.appstore.user.ui.upload.UploadAppActivity::class.java))
            }
        }
        binding.rowCheckUpdate.setOnClickListener {
            com.appstore.user.ui.update.CheckUpdateDialog(requireContext(), viewLifecycleOwner.lifecycleScope).show()
        }
        binding.rowMyAppsGames.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.dashboard.DeveloperDashboardActivity::class.java))
        }
        binding.rowHelpFeedback.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.help.HelpFeedbackActivity::class.java))
        }
        binding.rowPrivacyPolicy.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.privacy.PrivacyPolicyActivity::class.java))
        }
        binding.rowAboutCard.setOnClickListener {
            startActivity(Intent(requireContext(), com.appstore.user.ui.about.AboutActivity::class.java))
        }
        binding.rowLogoutCard.setOnClickListener {
            if (authRepository.isGuest) {
                // Nothing to log out of yet — take them straight to Login/Register.
                startActivity(Intent(requireContext(), LoginActivity::class.java))
            } else {
                logoutAndReturnToGuestBrowsing()
            }
        }
    }

    private fun bindUser() {
        val user = FirebaseAuth.getInstance().currentUser
        val isGuest = authRepository.isGuest

        binding.tvName.text = user?.displayName?.takeIf { it.isNotBlank() } ?: "Guest User"
        binding.tvEmail.text = if (isGuest) "Browsing as guest" else (user?.email ?: "")
        binding.tvLogoutLabel.text = if (isGuest) "Login / Register" else "Logout"
        user?.photoUrl?.let { Glide.with(this).load(it).into(binding.ivProfile) }

        // Older accounts created before the Auth profile name was set fall back
        // to the name saved in Firestore instead of staying stuck on "Guest User".
        if (user != null && !isGuest && user.displayName.isNullOrBlank()) {
            FirebaseFirestore.getInstance().collection(Constants.COLLECTION_USERS)
                .document(user.uid).get()
                .addOnSuccessListener { snap ->
                    if (_binding == null) return@addOnSuccessListener
                    val name = snap.getString("name")
                    if (!name.isNullOrBlank()) binding.tvName.text = name
                }
        }
    }

    private fun uploadProfilePhoto(uri: Uri) {
        Glide.with(this).load(uri).into(binding.ivProfile)
        lifecycleScope.launch {
            val uploadResult = publishRepository.uploadImageToImgbb(requireContext(), uri)
            val photoUrl = uploadResult.getOrElse {
                toast("Couldn't upload photo — please try again")
                return@launch
            }
            authRepository.updateProfilePhoto(photoUrl).onFailure {
                toast("Couldn't save photo — please try again")
            }
        }
    }

    /** Guests haven't created an account, so tapping "Upload App" should
     *  invite them to sign in instead of opening the upload form. */
    private fun showLoginRequiredDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Sign in required")
            .setMessage("Please login or create an account to upload your app.")
            .setPositiveButton("Login / Register") { d, _ ->
                d.dismiss()
                startActivity(Intent(requireContext(), LoginActivity::class.java))
            }
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .show()
    }

    /** After a real account signs out, go back to guest browsing rather than
     *  forcing the Login screen — only uploading an app requires an account. */
    private fun logoutAndReturnToGuestBrowsing() {
        FirebaseAuth.getInstance().signOut()
        lifecycleScope.launch {
            authRepository.signInAsGuest()
            val intent = Intent(requireContext(), MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            requireActivity().finishAffinity()
        }
    }

    private fun openCollections(tab: Int) {
        val intent = Intent(requireContext(), com.appstore.user.ui.collections.CollectionsActivity::class.java)
        intent.putExtra(com.appstore.user.utils.Constants.EXTRA_START_TAB, tab)
        startActivity(intent)
    }

    private fun toast(msg: String) = Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
