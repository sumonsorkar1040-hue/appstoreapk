package com.appstore.user

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.firestore.FirebaseFirestore
import java.io.PrintWriter
import java.io.StringWriter

class AppStoreApplication : Application() {

    companion object {
        const val CHANNEL_ID_UPDATES = "channel_app_updates"
        const val CHANNEL_ID_GENERAL = "channel_general"
    }

    override fun onCreate() {
        super.onCreate()

        installCrashHandler()

        FirebaseApp.initializeApp(this)

        // Firestore's offline disk cache is enabled by default, so lists/details
        // keep working without a connection with no extra setup needed here.
        FirebaseFirestore.getInstance()

        // App Check guards Firestore / Storage against abuse from tampered/rooted clients.
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )

        createNotificationChannels()
    }

    private fun installCrashHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))

                val intent = Intent(this, CrashActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    putExtra(CrashActivity.EXTRA_STACK_TRACE, sw.toString())
                }
                startActivity(intent)
            } catch (_: Exception) {
                // If we can't even show the crash screen, fall back to default behavior below.
            } finally {
                Process.killProcess(Process.myPid())
                Runtime.getRuntime().exit(10)
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID_UPDATES, "App Updates", NotificationManager.IMPORTANCE_DEFAULT)
            )
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID_GENERAL, "General", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }
}
