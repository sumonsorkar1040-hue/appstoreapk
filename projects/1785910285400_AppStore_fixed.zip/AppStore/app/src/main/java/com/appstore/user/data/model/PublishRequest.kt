package com.appstore.user.data.model

/**
 * Represents an app submitted by a user through the "Upload App" screen.
 * Written into Cloud Firestore's "apps" collection (same collection the
 * Admin Panel manages) with status = "PENDING". An admin reviews it from
 * the Admin Panel's Requests screen and approves it to status = "PUBLISHED"
 * (or rejects it) — it never lives in a separate table.
 */
data class PublishRequest(
    var id: String = "",
    var ownerUid: String = "",
    var ownerName: String = "",
    var ownerEmail: String = "",

    var appName: String = "",
    var developerName: String = "",
    var category: String = "",
    var isGame: Boolean = false,
    var isFree: Boolean = true,

    var packageName: String = "",
    var versionName: String = "",
    var versionCode: String = "",

    var shortDescription: String = "",
    var description: String = "",
    var whatsNew: String = "",

    var iconUrl: String = "",
    var screenshots: List<String> = emptyList(),
    var featureGraphicUrl: String = "",

    var apkUrl: String = "",
    var apkFileName: String = "",
    var fileSizeMb: Double = 0.0,

    var privacyPolicyUrl: String = "",
    var tags: List<String> = emptyList(),

    // pending -> approved -> published, or rejected
    var status: String = "pending",
    var reviewNote: String = "",

    var submittedAt: Long = 0,
    var reviewedAt: Long = 0
)
