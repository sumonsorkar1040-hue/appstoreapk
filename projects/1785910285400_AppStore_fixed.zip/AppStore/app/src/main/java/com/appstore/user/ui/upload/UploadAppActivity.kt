package com.appstore.user.ui.upload

import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.appstore.user.R
import com.appstore.user.data.model.PublishRequest
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.data.repository.PublishRepository
import com.appstore.user.databinding.ActivityUploadAppBinding
import com.appstore.user.databinding.ItemUploadScreenshotBinding
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Upload App" screen, reachable from Profile -> Upload App.
 *
 * Flow:
 *  1. Developer fills in app details and picks an icon, 3-8 screenshots,
 *     a feature graphic banner, and an APK file.
 *  2. On submit, images are uploaded to imgbb and the APK is uploaded
 *     directly to a GitHub repository (Contents API) using a personal
 *     access token.
 *  3. The submission is written straight into Firestore's "apps" collection
 *     with status = "PENDING". It only becomes a live store listing once an
 *     admin approves it (flips status to PUBLISHED) from the Admin Panel.
 */
class UploadAppActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUploadAppBinding
    private val publishRepository = PublishRepository()
    private val appRepository = AppRepository()

    private var iconUri: Uri? = null
    private var bannerUri: Uri? = null
    private var apkUri: Uri? = null
    private var apkFileName: String = ""
    private val screenshotUris = mutableListOf<Uri>()

    private val pickIcon = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            iconUri = uri
            binding.ivAppIconPreview.visibility = View.VISIBLE
            binding.layoutIconPlaceholder.visibility = View.GONE
            Glide.with(this).load(uri).centerCrop().into(binding.ivAppIconPreview)
        }
    }

    private val pickBanner = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            bannerUri = uri
            binding.ivBannerPreview.visibility = View.VISIBLE
            binding.layoutBannerPlaceholder.visibility = View.GONE
            Glide.with(this).load(uri).centerCrop().into(binding.ivBannerPreview)
        }
    }

    private val pickScreenshots = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val room = 8 - screenshotUris.size
            if (room <= 0) {
                toast("Maximum 8 screenshots allowed")
            } else {
                screenshotUris.addAll(uris.take(room))
                renderScreenshots()
            }
        }
    }

    private val pickApk = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val name = queryFileName(uri)
            if (!name.lowercase().endsWith(".apk")) {
                toast("Please select a valid .apk file")
                return@registerForActivityResult
            }
            apkUri = uri
            apkFileName = name
            binding.tvApkFileName.text = name
            extractApkInfo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadAppBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null || user.isAnonymous) {
            toast("Please login or create an account to upload your app")
            finish()
            return
        }

        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the top bar. Pad the root container (not the
        // top bar itself) by the top inset, so the top bar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, mutableListOf<String>())
        binding.actvCategory.setAdapter(adapter)
        binding.actvCategory.setOnClickListener { binding.actvCategory.showDropDown() }
        loadCategories(adapter, gamesOnly = binding.rbTypeGame.isChecked)
        binding.rgAppType.setOnCheckedChangeListener { _, _ ->
            binding.actvCategory.setText("", false)
            loadCategories(adapter, gamesOnly = binding.rbTypeGame.isChecked)
        }

        binding.ivBack.setOnClickListener { finish() }
        binding.boxAppIcon.setOnClickListener { pickIcon.launch("image/*") }
        binding.boxBanner.setOnClickListener { pickBanner.launch("image/*") }
        binding.btnAddScreenshots.setOnClickListener { pickScreenshots.launch("image/*") }
        binding.rowSelectApk.setOnClickListener {
            pickApk.launch("application/vnd.android.package-archive")
        }
        binding.btnUploadApp.setOnClickListener { validateAndSubmit() }
    }

    private fun loadCategories(adapter: ArrayAdapter<String>, gamesOnly: Boolean) {
        lifecycleScope.launch {
            val categories = appRepository.getCategories(gamesOnly = gamesOnly).map { it.name }
            adapter.clear()
            adapter.addAll(categories)
            adapter.notifyDataSetChanged()
        }
    }

    private fun renderScreenshots() {
        binding.llScreenshots.removeAllViews()
        binding.scrollScreenshots.visibility = if (screenshotUris.isEmpty()) View.GONE else View.VISIBLE
        screenshotUris.forEachIndexed { index, uri ->
            val itemBinding = ItemUploadScreenshotBinding.inflate(
                LayoutInflater.from(this), binding.llScreenshots, false
            )
            Glide.with(this).load(uri).centerCrop().into(itemBinding.ivThumb)
            itemBinding.ivRemove.setOnClickListener {
                screenshotUris.removeAt(index)
                renderScreenshots()
            }
            binding.llScreenshots.addView(itemBinding.root)
        }
    }

    private fun queryFileName(uri: Uri): String {
        var name = uri.lastPathSegment.orEmpty()
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    /**
     * Copies the picked APK to a temp file and reads its manifest via
     * PackageManager to auto-fill Package Name, Version Name, and Version
     * Code. Those fields are then locked (read-only) so they always match
     * what is actually inside the uploaded APK.
     */
    private fun extractApkInfo(uri: Uri) {
        lifecycleScope.launch {
            val info = withContext(Dispatchers.IO) {
                var tempFile: File? = null
                try {
                    tempFile = File.createTempFile("upload_", ".apk", cacheDir)
                    contentResolver.openInputStream(uri)?.use { input ->
                        tempFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    val pm = packageManager
                    val packageInfo = pm.getPackageArchiveInfo(tempFile.absolutePath, 0)
                    if (packageInfo != null) {
                        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            packageInfo.longVersionCode.toString()
                        } else {
                            @Suppress("DEPRECATION")
                            packageInfo.versionCode.toString()
                        }
                        Triple(packageInfo.packageName, packageInfo.versionName ?: "", versionCode)
                    } else null
                } catch (e: Exception) {
                    null
                } finally {
                    tempFile?.delete()
                }
            }

            if (info == null) {
                toast("Couldn't read version info from this APK — please enter it manually")
                unlockVersionFields()
                return@launch
            }

            val (pkg, versionName, versionCode) = info
            binding.etPackageName.setText(pkg)
            binding.etVersionName.setText(versionName)
            binding.etVersionCode.setText(versionCode)
            lockVersionFields()
            binding.tvApkAutoDetected.visibility = View.VISIBLE
        }
    }

    private fun lockVersionFields() {
        listOf(binding.etPackageName, binding.etVersionName, binding.etVersionCode).forEach { field ->
            field.isEnabled = false
            field.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_input_field_locked)
        }
    }

    private fun unlockVersionFields() {
        listOf(binding.etPackageName, binding.etVersionName, binding.etVersionCode).forEach { field ->
            field.isEnabled = true
            field.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_input_field)
        }
        binding.tvApkAutoDetected.visibility = View.GONE
    }

    private fun validateAndSubmit() {
        val appName = binding.etAppName.text?.toString()?.trim().orEmpty()
        val developerName = binding.etDeveloperName.text?.toString()?.trim().orEmpty()
        val category = binding.actvCategory.text?.toString()?.trim().orEmpty()
        val versionName = binding.etVersionName.text?.toString()?.trim().orEmpty()
        val versionCode = binding.etVersionCode.text?.toString()?.trim().orEmpty()
        val packageName = binding.etPackageName.text?.toString()?.trim().orEmpty()
        val shortDescription = binding.etShortDescription.text?.toString()?.trim().orEmpty()
        val fullDescription = binding.etFullDescription.text?.toString()?.trim().orEmpty()
        val whatsNew = binding.etWhatsNew.text?.toString()?.trim().orEmpty()
        val privacyPolicyUrl = binding.etPrivacyPolicyUrl.text?.toString()?.trim().orEmpty()
        val tags = binding.etTags.text?.toString()?.trim().orEmpty()

        if (iconUri == null) { toast("Please upload an app icon"); return }
        if (appName.isEmpty()) { toast("App Name is required"); binding.etAppName.requestFocus(); return }
        if (developerName.isEmpty()) { toast("Developer Name is required"); binding.etDeveloperName.requestFocus(); return }
        if (category.isEmpty()) { toast("Please select a category"); return }
        if (apkUri == null) { toast("Please select an APK file"); return }
        if (versionName.isEmpty()) { toast("Version Name is required"); binding.etVersionName.requestFocus(); return }
        if (versionCode.isEmpty()) { toast("Version Code is required"); binding.etVersionCode.requestFocus(); return }
        if (packageName.isEmpty()) { toast("Package Name is required"); binding.etPackageName.requestFocus(); return }
        if (shortDescription.isEmpty()) { toast("Short Description is required"); binding.etShortDescription.requestFocus(); return }
        if (fullDescription.isEmpty()) { toast("Full Description is required"); binding.etFullDescription.requestFocus(); return }
        if (screenshotUris.size < 3) { toast("Please add at least 3 screenshots"); return }
        if (bannerUri == null) { toast("Please upload a feature graphic banner"); return }

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) { toast("Please sign in to upload an app"); return }

        submitFlow(
            PublishRequest(
                ownerUid = user.uid,
                ownerName = user.displayName.orEmpty(),
                ownerEmail = user.email.orEmpty(),
                appName = appName,
                developerName = developerName,
                category = category,
                isGame = binding.rbTypeGame.isChecked,
                isFree = binding.rbFree.isChecked,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                shortDescription = shortDescription,
                description = fullDescription,
                whatsNew = whatsNew,
                privacyPolicyUrl = privacyPolicyUrl,
                tags = tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            )
        )
    }

    private fun submitFlow(base: PublishRequest) {
        setLoading(true)

        lifecycleScope.launch {
            try {
                setStatus("Uploading app icon…")
                val iconResult = publishRepository.uploadImageToImgbb(this@UploadAppActivity, iconUri!!)
                val iconUrl = iconResult.getOrElse { throw it }

                setStatus("Uploading feature graphic…")
                val bannerResult = publishRepository.uploadImageToImgbb(this@UploadAppActivity, bannerUri!!)
                val bannerUrl = bannerResult.getOrElse { throw it }

                val screenshotUrls = mutableListOf<String>()
                screenshotUris.forEachIndexed { index, uri ->
                    setStatus("Uploading screenshot ${index + 1} of ${screenshotUris.size}…")
                    val result = publishRepository.uploadImageToImgbb(this@UploadAppActivity, uri)
                    screenshotUrls.add(result.getOrElse { throw it })
                }

                setStatus("Uploading APK to GitHub… this may take a moment")
                val apkResult = publishRepository.uploadApkToGithub(this@UploadAppActivity, apkUri!!, apkFileName)
                val (apkUrl, sizeMb) = apkResult.getOrElse { throw it }

                setStatus("Submitting for admin review…")
                val request = base.copy(
                    iconUrl = iconUrl,
                    featureGraphicUrl = bannerUrl,
                    screenshots = screenshotUrls,
                    apkUrl = apkUrl,
                    apkFileName = apkFileName,
                    fileSizeMb = sizeMb
                )
                publishRepository.submitPublishRequest(request).getOrElse { throw it }

                setLoading(false)
                showSuccessDialog()
            } catch (e: Exception) {
                setLoading(false)
                toast("Upload failed: ${e.message}")
            }
        }
    }

    private fun showSuccessDialog() {
        AlertDialog.Builder(this)
            .setTitle("Submitted for Review")
            .setMessage("Your app has been sent to the admin for approval. It will be published to the store once approved.")
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ -> finish() }
            .show()
    }

    private fun setLoading(loading: Boolean) {
        binding.btnUploadApp.isEnabled = !loading
        binding.btnUploadApp.alpha = if (loading) 0.6f else 1f
        binding.layoutUploadStatus.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun setStatus(text: String) {
        binding.tvUploadStatus.text = text
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
