package com.appstore.user.data.model

data class Feedback(
    var id: String = "",
    var userId: String = "",
    var userName: String = "",
    var userEmail: String = "",
    var type: String = "",
    var message: String = "",
    var appVersion: String = "",
    var timestamp: Long = 0
)
