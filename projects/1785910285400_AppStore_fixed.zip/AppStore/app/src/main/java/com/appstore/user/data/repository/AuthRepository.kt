package com.appstore.user.data.repository

import android.net.Uri
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.appstore.user.data.model.UserModel
import com.appstore.user.utils.Constants
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await

sealed class AuthResult {
    data class Success(val user: FirebaseUser) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    val currentUser get() = auth.currentUser

    /** True once the current session is Firebase's anonymous "guest" account
     *  rather than a real, registered account. */
    val isGuest: Boolean get() = auth.currentUser?.isAnonymous == true

    /** Signs the device in as a Firebase anonymous ("guest") user, so people
     *  can browse the store without creating an account first. */
    suspend fun signInAsGuest(): AuthResult = suspendCancellableCoroutine { cont ->
        auth.signInAnonymously()
            .addOnSuccessListener { result ->
                val user = result.user
                if (user != null) cont.resume(AuthResult.Success(user))
                else cont.resume(AuthResult.Error("Guest sign-in failed"))
            }
            .addOnFailureListener { e -> cont.resume(AuthResult.Error(e.message ?: "Guest sign-in failed")) }
    }

    suspend fun loginWithEmail(email: String, password: String): AuthResult =
        suspendCancellableCoroutine { cont ->
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (user != null) cont.resume(AuthResult.Success(user))
                    else cont.resume(AuthResult.Error("Login failed"))
                }
                .addOnFailureListener { e -> cont.resume(AuthResult.Error(e.message ?: "Login failed")) }
        }

    suspend fun registerWithEmail(
        name: String,
        phone: String,
        email: String,
        password: String,
        photoUrl: String = ""
    ): AuthResult =
        suspendCancellableCoroutine { cont ->
            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (user != null) {
                        val profileUpdate = UserProfileChangeRequest.Builder()
                            .setDisplayName(name)
                            .apply { if (photoUrl.isNotEmpty()) setPhotoUri(Uri.parse(photoUrl)) }
                            .build()
                        user.updateProfile(profileUpdate).addOnCompleteListener {
                            saveUserProfile(user.uid, name, phone, email, photoUrl)
                            user.sendEmailVerification()
                            cont.resume(AuthResult.Success(user))
                        }
                    } else cont.resume(AuthResult.Error("Registration failed"))
                }
                .addOnFailureListener { e -> cont.resume(AuthResult.Error(e.message ?: "Registration failed")) }
        }

    suspend fun loginWithGoogle(credential: AuthCredential): AuthResult =
        suspendCancellableCoroutine { cont ->
            auth.signInWithCredential(credential)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (user != null) {
                        saveUserProfile(user.uid, user.displayName ?: "", "", user.email ?: "", user.photoUrl?.toString() ?: "")
                        cont.resume(AuthResult.Success(user))
                    } else cont.resume(AuthResult.Error("Google sign-in failed"))
                }
                .addOnFailureListener { e -> cont.resume(AuthResult.Error(e.message ?: "Google sign-in failed")) }
        }

    suspend fun sendPasswordReset(email: String): Result<Unit> = suspendCancellableCoroutine { cont ->
        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener { cont.resume(Result.success(Unit)) }
            .addOnFailureListener { e -> cont.resume(Result.failure(e)) }
    }

    /**
     * Writes to Firestore's "users" collection — the same collection the
     * Admin Panel's Users screen reads (FirebaseRepository.getUsers()).
     * Only writes on first sign-in so it never overwrites fields the admin
     * has set on this doc (isBanned, etc.).
     */
    private fun saveUserProfile(uid: String, name: String, phone: String, email: String, photoUrl: String) {
        val ref = db.collection(Constants.COLLECTION_USERS).document(uid)
        ref.get().addOnSuccessListener { snap ->
            if (!snap.exists()) {
                ref.set(
                    UserModel(
                        uid = uid,
                        name = name,
                        phone = phone,
                        email = email,
                        photoUrl = photoUrl,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    /** True if the admin has banned this account from the Users screen. */
    suspend fun isCurrentUserBanned(): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        return try {
            db.collection(Constants.COLLECTION_USERS).document(uid).get().await()
                .getBoolean("isBanned") ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun logout() = auth.signOut()

    /** Updates the current user's photo — both the Firebase Auth profile and
     *  the Firestore users/{uid} doc — so it's reflected everywhere,
     *  including the Admin Panel. Works for guest (anonymous) accounts too. */
    suspend fun updateProfilePhoto(photoUrl: String): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(Exception("Not signed in"))
        return try {
            user.updateProfile(UserProfileChangeRequest.Builder().setPhotoUri(Uri.parse(photoUrl)).build()).await()
            db.collection(Constants.COLLECTION_USERS).document(user.uid)
                .set(mapOf("photoUrl" to photoUrl), com.google.firebase.firestore.SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
