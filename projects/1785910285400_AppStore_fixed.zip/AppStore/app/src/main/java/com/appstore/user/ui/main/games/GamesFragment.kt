package com.appstore.user.ui.main.games

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.appstore.user.R
import com.appstore.user.adapter.AppGridAdapter
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.data.model.Category
import com.appstore.user.databinding.FragmentGamesBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.ui.main.apps.CategoryBrowseViewModel
import com.appstore.user.utils.Constants

class GamesFragment : Fragment() {

    private var _binding: FragmentGamesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CategoryBrowseViewModel by viewModels()

    private var isGridView = false

    private val listAdapter = AppListAdapter(
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> openDetail(app.id) }
    )
    private val gridAdapter = AppGridAdapter(
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> openDetail(app.id) }
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGamesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvGames.layoutManager = LinearLayoutManager(requireContext())
        binding.rvGames.adapter = listAdapter

        binding.ivToggleView.setOnClickListener {
            isGridView = !isGridView
            applyViewMode()
        }

        viewModel.categories.observe(viewLifecycleOwner) { populateChips(it) }
        viewModel.apps.observe(viewLifecycleOwner) {
            listAdapter.submitList(it)
            gridAdapter.submitList(it)
        }
        viewModel.isLoading.observe(viewLifecycleOwner) { binding.swipeRefresh.isRefreshing = it }

        binding.swipeRefresh.setOnRefreshListener {
            val selectedChip = binding.chipGroupCategories.findViewById<Chip>(binding.chipGroupCategories.checkedChipId)
            selectedChip?.text?.toString()?.let { viewModel.loadApps(it) }
        }

        viewModel.loadCategories(gamesOnly = true)
    }

    /** Switches the games RecyclerView between List view and Grid view. */
    private fun applyViewMode() {
        if (isGridView) {
            binding.rvGames.layoutManager = GridLayoutManager(requireContext(), 2)
            binding.rvGames.adapter = gridAdapter
            binding.ivToggleView.setImageResource(R.drawable.ic_view_list)
        } else {
            binding.rvGames.layoutManager = LinearLayoutManager(requireContext())
            binding.rvGames.adapter = listAdapter
            binding.ivToggleView.setImageResource(R.drawable.ic_view_grid)
        }
    }

    private fun populateChips(categories: List<Category>) {
        binding.chipGroupCategories.removeAllViews()
        categories.forEachIndexed { index, category ->
            val chip = Chip(requireContext()).apply {
                text = category.name
                isCheckable = true
                isChecked = index == 0
                setOnClickListener { viewModel.loadApps(category.name) }
            }
            binding.chipGroupCategories.addView(chip)
        }
        categories.firstOrNull()?.let { viewModel.loadApps(it.name) }
    }

    private fun openDetail(appId: String) {
        val intent = Intent(requireContext(), AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
