package com.appstore.user.ui.collections

import android.content.Intent
import android.os.Bundle
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityCollectionsBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants

class CollectionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCollectionsBinding
    private val viewModel: CollectionsViewModel by lazy { ViewModelProvider(this)[CollectionsViewModel::class.java] }
    private val repository = AppRepository()

    private var currentTab = 0 // 0 = Wishlist, 1 = Favorites

    private val listAdapter = AppListAdapter(
        actionLabel = "Remove",
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> removeFromCollection(app.id) }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCollectionsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the toolbar. Pad the root container (not the
        // toolbar itself) by the top inset, so the toolbar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvList.layoutManager = LinearLayoutManager(this)
        binding.rvList.adapter = listAdapter

        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Wishlist"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Favorites"))
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { currentTab = tab.position; renderCurrentTab() }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        val startTab = intent.getIntExtra(Constants.EXTRA_START_TAB, 0)
        binding.tabLayout.getTabAt(startTab)?.select()
        currentTab = startTab

        viewModel.wishlist.observe(this) { if (currentTab == 0) renderCurrentTab() }
        viewModel.favorites.observe(this) { if (currentTab == 1) renderCurrentTab() }
        viewModel.load()
    }

    override fun onResume() {
        super.onResume()
        viewModel.load()
    }

    private fun renderCurrentTab() {
        val list = if (currentTab == 0) viewModel.wishlist.value.orEmpty() else viewModel.favorites.value.orEmpty()
        listAdapter.submitList(list)
        binding.emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        binding.tvEmptyMessage.text = if (currentTab == 0) "No apps in your wishlist yet" else "No favorite apps yet"
    }

    private fun removeFromCollection(appId: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        if (currentTab == 0) repository.setWishlisted(uid, appId, false)
        else repository.setFavorited(uid, appId, false)
        viewModel.load()
    }

    private fun openDetail(appId: String) {
        val intent = Intent(this, AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }
}
