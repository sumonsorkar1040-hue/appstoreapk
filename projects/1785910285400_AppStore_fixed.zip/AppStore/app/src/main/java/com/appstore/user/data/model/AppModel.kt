package com.appstore.user.data.model

/**
 * Represents a single app or game document read from the Cloud Firestore
 * "apps" collection (the same collection AppStoreAdmin's admin panel
 * manages). AppRepository maps the admin's Firestore field names onto this
 * shape, so this stays a flat data class independent of the admin schema.
 */
data class AppModel(
    var id: String = "",
    var name: String = "",
    var developer: String = "",
    var developerVerified: Boolean = false,
    var iconUrl: String = "",
    var screenshots: List<String> = emptyList(),
    var promoVideoUrl: String = "",
    var packageName: String = "",
    var category: String = "",
    var isGame: Boolean = false,
    var shortDescription: String = "",
    var description: String = "",
    var whatsNew: String = "",
    var version: String = "",
    var apkUrl: String = "",
    var fileSizeMb: Double = 0.0,
    var minAndroidVersion: String = "",
    var ageRating: String = "",
    var downloadsCount: Long = 0,
    var rating: Double = 0.0,
    var ratingCount: Long = 0,
    var permissions: List<String> = emptyList(),
    var dataSafetyNotes: String = "",
    var privacyPolicyUrl: String = "",
    var isFeatured: Boolean = false,
    var isEditorChoice: Boolean = false,
    var isTrending: Boolean = false,
    var isTopChart: Boolean = false,
    var isNewRelease: Boolean = false,
    var createdAt: Long = 0,
    var updatedAt: Long = 0,
    /** IDs of admin-created custom Home sections (Constants.COLLECTION_HOME_SECTIONS)
     *  this app was added to at publish time — lets the admin place an app into any
     *  number of unlimited, custom sections like "New Releases" or "Top Charts". */
    var homeSectionIds: List<String> = emptyList()
)
