package com.appstore.user

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Minimal, dependency-free crash screen.
 * Shown automatically whenever the app has an uncaught exception (see AppStoreApplication).
 * Lets you read and copy the stack trace directly on the device, no logcat/PC needed.
 */
class CrashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val stackTrace = intent.getStringExtra(EXTRA_STACK_TRACE) ?: "No crash details available."

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
            setPadding(32, 64, 32, 32)
        }

        val title = TextView(this).apply {
            text = "App crashed 😕"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Copy the details below and share them to get this fixed."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 0, 0, 24)
        }
        root.addView(subtitle)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val traceView = TextView(this).apply {
            text = stackTrace
            setTextColor(Color.parseColor("#FF8A80"))
            textSize = 12f
            setTextIsSelectable(true)
        }
        scrollView.addView(traceView)
        root.addView(scrollView)

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, 24, 0, 0)
        }

        val copyButton = Button(this).apply {
            text = "Copy"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Crash log", stackTrace))
                Toast.makeText(this@CrashActivity, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }
        val closeButton = Button(this).apply {
            text = "Close app"
            setOnClickListener {
                finishAffinity()
                Runtime.getRuntime().exit(0)
            }
        }

        buttonRow.addView(copyButton)
        buttonRow.addView(closeButton)
        root.addView(buttonRow)

        setContentView(root)
    }

    companion object {
        const val EXTRA_STACK_TRACE = "extra_stack_trace"
    }
}
