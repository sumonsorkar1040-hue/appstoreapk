package com.appstore.user.ui.auth

import android.app.Activity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.data.repository.AuthResult
import com.appstore.user.databinding.ActivityRegisterBinding
import com.appstore.user.ui.main.MainActivity
import com.appstore.user.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val authRepository = AuthRepository()

    private var selectedImageUri: Uri? = null
    private var uploadedPhotoUrl: String = ""

    companion object {
        private const val PICK_IMAGE_REQUEST = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        com.appstore.user.utils.SecurityHelper.applyScreenshotProtection(this)

        binding.ivProfilePic.setOnClickListener { openImagePicker() }
        binding.ivPickPhoto.setOnClickListener { openImagePicker() }
        binding.btnRegister.setOnClickListener { attemptRegister() }
        binding.tvGoToLogin.setOnClickListener { finish() }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data
            if (selectedImageUri != null) {
                binding.ivProfilePic.setImageURI(selectedImageUri)
                binding.tvUploadStatus.text = getString(com.appstore.user.R.string.photo_selected_uploading)
                uploadImageToImgbb(selectedImageUri!!)
            }
        }
    }

    private fun uploadImageToImgbb(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val inputStream = contentResolver.openInputStream(uri) ?: return@launch
                val bytes = inputStream.readBytes()
                inputStream.close()
                val base64Image = Base64.encodeToString(bytes, Base64.DEFAULT)

                val url = URL("${Constants.IMGBB_UPLOAD_URL}?key=${Constants.IMGBB_API_KEY}")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                val postData = "image=${java.net.URLEncoder.encode(base64Image, "UTF-8")}"
                val out = DataOutputStream(conn.outputStream)
                out.writeBytes(postData)
                out.flush()
                out.close()

                val response = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(response)
                val imageUrl = json.getJSONObject("data").getString("url")

                withContext(Dispatchers.Main) {
                    uploadedPhotoUrl = imageUrl
                    binding.tvUploadStatus.text = getString(com.appstore.user.R.string.photo_uploaded_success)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.tvUploadStatus.text = getString(com.appstore.user.R.string.photo_upload_failed)
                    uploadedPhotoUrl = ""
                }
            }
        }
    }

    private fun attemptRegister() {
        val name = binding.etName.text?.toString()?.trim().orEmpty()
        val phone = binding.etPhone.text?.toString()?.trim().orEmpty()
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString()?.trim().orEmpty()
        val confirmPassword = binding.etConfirmPassword.text?.toString()?.trim().orEmpty()

        // Clear errors
        binding.tilName.error = null
        binding.tilPhone.error = null
        binding.tilEmail.error = null
        binding.tilPassword.error = null
        binding.tilConfirmPassword.error = null

        // Validate
        if (name.isEmpty()) { binding.tilName.error = "Name is required"; return }
        if (phone.isEmpty()) { binding.tilPhone.error = "Phone number is required"; return }
        if (email.isEmpty()) { binding.tilEmail.error = "Email is required"; return }
        if (password.length < 6) { binding.tilPassword.error = "Minimum 6 characters"; return }
        if (confirmPassword.isEmpty()) { binding.tilConfirmPassword.error = "Please confirm your password"; return }
        if (password != confirmPassword) { binding.tilConfirmPassword.error = "Passwords do not match"; return }
        if (!binding.cbAgree.isChecked) { toast("Please agree to the Terms & Conditions"); return }

        if (selectedImageUri != null && uploadedPhotoUrl.isEmpty()) {
            toast("Please wait, photo is still uploading...")
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.registerWithEmail(name, phone, email, password, uploadedPhotoUrl)) {
                is AuthResult.Success -> {
                    toast("Account created. Please verify your email.")
                    startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                    finishAffinity()
                }
                is AuthResult.Error -> { setLoading(false); toast(result.message) }
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !loading
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
