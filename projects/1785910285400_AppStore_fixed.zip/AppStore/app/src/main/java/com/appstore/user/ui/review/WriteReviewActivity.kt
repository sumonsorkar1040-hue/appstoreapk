package com.appstore.user.ui.review

import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.data.model.Review
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityWriteReviewBinding
import com.appstore.user.utils.Constants
import kotlinx.coroutines.launch

class WriteReviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWriteReviewBinding
    private val repository = AppRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWriteReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        val appId = intent.getStringExtra(Constants.EXTRA_APP_ID).orEmpty()
        val appName = intent.getStringExtra(Constants.EXTRA_SECTION_TITLE).orEmpty()
        binding.tvAppName.text = appName

        val presetRating = intent.getFloatExtra(Constants.EXTRA_PRESET_RATING, 0f)
        if (presetRating > 0f) binding.ratingBar.rating = presetRating

        binding.ivClose.setOnClickListener { finish() }
        binding.btnSubmit.setOnClickListener { submit(appId) }
    }

    private fun submit(appId: String) {
        val rating = binding.ratingBar.rating
        val comment = binding.etComment.text?.toString()?.trim().orEmpty()

        if (rating == 0f) {
            Toast.makeText(this, "Please select a star rating", Toast.LENGTH_SHORT).show()
            return
        }

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(this, "Please log in to leave a review", Toast.LENGTH_SHORT).show()
            return
        }

        setLoading(true)
        val review = Review(
            appId = appId,
            userId = user.uid,
            userName = user.displayName ?: "Anonymous",
            userPhotoUrl = user.photoUrl?.toString() ?: "",
            rating = rating,
            comment = comment,
            timestamp = System.currentTimeMillis()
        )

        lifecycleScope.launch {
            val result = repository.submitReview(appId, review)
            setLoading(false)
            if (result.isSuccess) {
                Toast.makeText(this@WriteReviewActivity, "Review submitted", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this@WriteReviewActivity, result.exceptionOrNull()?.message ?: "Failed to submit", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnSubmit.isEnabled = !loading
    }
}
