package com.appstore.user.data.model

data class Category(
    var id: String = "",
    var name: String = "",
    var iconUrl: String = "",
    var isGameCategory: Boolean = false,
    var sortOrder: Int = 0
)
