package com.appstore.user.ui.main.apps

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.model.Category
import com.appstore.user.data.repository.AppRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class CategoryBrowseViewModel : ViewModel() {

    private val repository = AppRepository()

    private val _categories = MutableLiveData<List<Category>>()
    val categories: LiveData<List<Category>> = _categories

    private val _apps = MutableLiveData<List<AppModel>>()
    val apps: LiveData<List<AppModel>> = _apps

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    fun loadCategories(gamesOnly: Boolean) {
        viewModelScope.launch {
            _categories.value = repository.getCategories(gamesOnly)
        }
    }

    fun loadApps(category: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                withTimeoutOrNull(15_000L) {
                    _apps.value = repository.getAppsByCategory(category)
                }
            } catch (_: Exception) {
                // Fall through to `finally` so the shimmer always hides.
            } finally {
                _isLoading.value = false
            }
        }
    }
}
