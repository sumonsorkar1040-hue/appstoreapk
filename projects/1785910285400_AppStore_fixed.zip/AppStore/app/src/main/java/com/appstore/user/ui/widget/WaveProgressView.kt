package com.appstore.user.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.sin

/**
 * A rounded pill that fills from the bottom with an animated wavy liquid as [progress] rises,
 * with the "N%" label riding on the wave's surface (and switching to white once the liquid
 * covers it). The fill color eases from orange to green as progress approaches 100.
 */
class WaveProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Target progress 0-100. Setting this smoothly animates the liquid level to the new value. */
    var progress: Int = 0
        set(value) {
            field = value.coerceIn(0, 100)
            animateLevelTo(field)
        }

    private var displayedProgress = 0f
    private var levelAnimator: ValueAnimator? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EEF1F6")
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        color = Color.parseColor("#FF7A1A")
    }

    private val orangeColor = Color.parseColor("#FF7A1A")
    private val greenColor = Color.parseColor("#2ECC71")

    private var wavePhase = 0f
    private val waveAnimator = ValueAnimator.ofFloat(0f, (2f * PI).toFloat()).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            wavePhase = it.animatedValue as Float
            invalidate()
        }
    }

    private val clipPath = Path()
    private val wavePath = Path()

    init {
        textPaint.textSize = resources.displayMetrics.density * 15f
    }

    /** Starts the looping wave motion. Call when the pill becomes visible. */
    fun start() {
        if (!waveAnimator.isStarted) waveAnimator.start()
    }

    /** Stops all animation and resets the fill back to empty. */
    fun stop() {
        waveAnimator.cancel()
        levelAnimator?.cancel()
        displayedProgress = 0f
        progress = 0
        invalidate()
    }

    private fun animateLevelTo(target: Int) {
        levelAnimator?.cancel()
        levelAnimator = ValueAnimator.ofFloat(displayedProgress, target.toFloat()).apply {
            duration = 350
            addUpdateListener {
                displayedProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clipPath.reset()
        val radius = h / 2f
        clipPath.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), radius, radius, Path.Direction.CW)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        canvas.save()
        canvas.clipPath(clipPath)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val fraction = (displayedProgress / 100f).coerceIn(0f, 1f)
        val fillColor = interpolateColor(fraction)
        wavePaint.color = fillColor

        val waterLevel = h * (1f - fraction)
        val amplitude = h * 0.07f
        val waveLength = w.coerceAtLeast(1f)

        wavePath.reset()
        wavePath.moveTo(0f, waterLevel)
        var x = 0f
        val step = 4f
        while (x <= w) {
            val y = waterLevel + amplitude * sin((x / waveLength) * 2f * PI.toFloat() + wavePhase).toFloat()
            wavePath.lineTo(x, y)
            x += step
        }
        wavePath.lineTo(w, h)
        wavePath.lineTo(0f, h)
        wavePath.close()
        canvas.drawPath(wavePath, wavePaint)
        canvas.restore()

        val text = "${displayedProgress.toInt()}%"
        val textY = (waterLevel - (textPaint.descent() + textPaint.ascent()) / 2f)
            .coerceIn(textPaint.textSize, h - 4f)
        textPaint.color = if (fraction > 0.55f) Color.WHITE else fillColor
        canvas.drawText(text, w / 2f, textY, textPaint)
    }

    private fun interpolateColor(fraction: Float): Int {
        val t = ((fraction - 0.6f) / 0.4f).coerceIn(0f, 1f)
        return ColorUtils.blendARGB(orangeColor, greenColor, t)
    }
}
