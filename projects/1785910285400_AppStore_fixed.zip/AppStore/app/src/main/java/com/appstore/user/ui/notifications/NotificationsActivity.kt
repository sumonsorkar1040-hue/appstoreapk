package com.appstore.user.ui.notifications

import android.content.Intent
import android.os.Bundle
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.adapter.NotificationAdapter
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityNotificationsBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants
import kotlinx.coroutines.launch

class NotificationsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationsBinding
    private val repository = AppRepository()

    private val adapter = NotificationAdapter { item ->
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null) repository.markNotificationRead(uid, item.id)
        if (item.appId.isNotEmpty()) {
            val intent = Intent(this, AppDetailActivity::class.java)
            intent.putExtra(Constants.EXTRA_APP_ID, item.appId)
            startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the toolbar. Pad the root container (not the
        // toolbar itself) by the top inset, so the toolbar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvNotifications.layoutManager = LinearLayoutManager(this)
        binding.rvNotifications.adapter = adapter

        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            binding.emptyState.visibility = View.VISIBLE
            return
        }

        lifecycleScope.launch {
            repository.observeNotifications(uid).collect { list ->
                adapter.submitList(list)
                binding.emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }
}
