package com.appstore.user.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.appstore.user.R
import com.appstore.user.data.model.PublishRequest
import com.appstore.user.data.repository.PublishRepository
import com.appstore.user.databinding.ActivityDeveloperDashboardBinding
import com.appstore.user.databinding.ItemDashboardAppBinding
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

/**
 * "My Apps & Games" screen, reachable from Profile -> My Apps & Games.
 *
 * Shows live totals (Total / Live / Pending) and the list of apps the
 * current user has submitted through "Upload App", with a status chip so
 * they can see whether each submission is still pending admin review,
 * approved, live on the store, or rejected (with the admin's note, if any).
 */
class DeveloperDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDeveloperDashboardBinding
    private val publishRepository = PublishRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeveloperDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the top bar. Pad the root container (not the
        // top bar itself) by the top inset, so the top bar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        binding.ivBack.setOnClickListener { finish() }
        binding.swipeRefresh.setOnRefreshListener { binding.swipeRefresh.isRefreshing = false }

        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            renderApps(emptyList())
            return
        }

        lifecycleScope.launch {
            publishRepository.observeMyPublishRequests(uid).collect { list ->
                renderApps(list)
            }
        }
    }

    private fun renderApps(list: List<PublishRequest>) {
        val total = list.size
        val live = list.count { it.status == "published" }
        val pending = list.count { it.status == "pending" }

        binding.tvTotalApps.text = total.toString()
        binding.tvLiveApps.text = live.toString()
        binding.tvPendingApps.text = pending.toString()

        binding.layoutEmptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        binding.llAppsList.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        binding.llAppsList.removeAllViews()

        list.forEach { app ->
            val itemBinding = ItemDashboardAppBinding.inflate(
                LayoutInflater.from(this), binding.llAppsList, false
            )
            Glide.with(this).load(app.iconUrl).placeholder(R.drawable.ic_launcher).into(itemBinding.ivAppIcon)
            itemBinding.tvAppName.text = app.appName
            itemBinding.tvAppMeta.text = "v${app.versionName} · ${app.packageName}"

            val (label, colorRes) = statusLabelAndColor(app.status)
            itemBinding.tvStatus.text = label
            itemBinding.tvStatus.background.setTint(ContextCompat.getColor(this, colorRes))

            if (app.status == "rejected" && app.reviewNote.isNotBlank()) {
                itemBinding.tvRejectReason.visibility = View.VISIBLE
                itemBinding.tvRejectReason.text = "Reason: ${app.reviewNote}"
            } else {
                itemBinding.tvRejectReason.visibility = View.GONE
            }

            binding.llAppsList.addView(itemBinding.root)
        }
    }

    private fun statusLabelAndColor(status: String): Pair<String, Int> = when (status) {
        "published" -> "Live" to R.color.stat_green
        "approved" -> "Approved" to R.color.stat_green
        "rejected" -> "Rejected" to R.color.stat_red
        else -> "Pending" to R.color.stat_orange
    }
}
