package com.appstore.user.ui.main.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.model.Banner
import com.appstore.user.data.model.Category
import com.appstore.user.data.model.HomeSection
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.utils.Constants
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** A custom Home section (admin-created, unlimited) paired with its published apps. */
data class HomeSectionWithApps(val section: HomeSection, val apps: List<AppModel>)

class HomeViewModel : ViewModel() {

    private val repository = AppRepository()

    private val _banners = MutableLiveData<List<Banner>>()
    val banners: LiveData<List<Banner>> = _banners

    private val _categories = MutableLiveData<List<Category>>()
    val categories: LiveData<List<Category>> = _categories

    private val _featuredApps = MutableLiveData<List<AppModel>>()
    val featuredApps: LiveData<List<AppModel>> = _featuredApps

    private val _editorsChoice = MutableLiveData<List<AppModel>>()
    val editorsChoice: LiveData<List<AppModel>> = _editorsChoice

    private val _trending = MutableLiveData<List<AppModel>>()
    val trending: LiveData<List<AppModel>> = _trending

    private val _newReleases = MutableLiveData<List<AppModel>>()
    val newReleases: LiveData<List<AppModel>> = _newReleases

    private val _topCharts = MutableLiveData<List<AppModel>>()
    val topCharts: LiveData<List<AppModel>> = _topCharts

    private val _featuredGames = MutableLiveData<List<AppModel>>()
    val featuredGames: LiveData<List<AppModel>> = _featuredGames

    /** Unlimited, admin-created custom sections (e.g. "New Releases", "Top Charts", ...). */
    private val _dynamicSections = MutableLiveData<List<HomeSectionWithApps>>()
    val dynamicSections: LiveData<List<HomeSectionWithApps>> = _dynamicSections

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    fun loadHome() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Guard every load with a timeout so a slow/hanging network call
                // (e.g. Firestore never responding) can never leave the shimmer
                // skeleton stuck on screen forever.
                withTimeoutOrNull(15_000L) {
                    _banners.value = repository.getBanners()
                    _categories.value = repository.getCategories(gamesOnly = false)
                    _featuredApps.value = repository.getSection(Constants.NODE_FEATURED)
                    _editorsChoice.value = repository.getSection(Constants.NODE_EDITOR_CHOICE)
                    _trending.value = repository.getSection(Constants.NODE_TRENDING)
                    _newReleases.value = repository.getSection(Constants.NODE_NEW_RELEASES)
                    _topCharts.value = repository.getSection(Constants.NODE_TOP_CHARTS)
                    _featuredGames.value = repository.getSection(Constants.NODE_FEATURED).filter { it.isGame }

                    val sections = repository.getHomeSections()
                    _dynamicSections.value = sections.map { section ->
                        HomeSectionWithApps(section, repository.getAppsByHomeSection(section.id))
                    }
                }
            } catch (_: Exception) {
                // Swallow and fall through to `finally` so the shimmer always hides,
                // even if a section failed to load.
            } finally {
                _isLoading.value = false
            }
        }
    }
}
