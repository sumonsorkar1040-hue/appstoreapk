package com.appstore.user.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.model.Review
import com.appstore.user.data.repository.AppRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AppDetailViewModel : ViewModel() {

    private val repository = AppRepository()

    private val _app = MutableLiveData<AppModel?>()
    val app: LiveData<AppModel?> = _app

    private val _similarApps = MutableLiveData<List<AppModel>>()
    val similarApps: LiveData<List<AppModel>> = _similarApps

    private val _reviews = MutableLiveData<List<Review>>(emptyList())
    val reviews: LiveData<List<Review>> = _reviews

    fun load(appId: String) {
        viewModelScope.launch {
            val loadedApp = repository.getAppById(appId)
            _app.value = loadedApp
            loadedApp?.let {
                _similarApps.value = repository.getAppsByCategory(it.category)
                    .filter { similar -> similar.id != appId }
                    .take(10)
            }
        }
        viewModelScope.launch {
            repository.observeReviews(appId).collectLatest { list -> _reviews.value = list }
        }
    }

    fun registerDownload(appId: String) = repository.incrementDownloadCount(appId)
}
