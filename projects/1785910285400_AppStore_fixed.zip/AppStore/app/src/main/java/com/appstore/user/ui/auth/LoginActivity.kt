package com.appstore.user.ui.auth

import android.content.Intent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider
import com.appstore.user.R
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.data.repository.AuthResult
import com.appstore.user.databinding.ActivityLoginBinding
import com.appstore.user.ui.main.MainActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val authRepository = AuthRepository()

    private val googleSignInClient by lazy {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        GoogleSignIn.getClient(this, gso)
    }

    private val googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            signInWithGoogleCredential(credential)
        } catch (e: ApiException) {
            toast("Google sign-in cancelled")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Status bar: dark background with light (white) icons for auth pages
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        com.appstore.user.utils.SecurityHelper.applyScreenshotProtection(this)

        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.btnGoogleSignIn.setOnClickListener { googleSignInLauncher.launch(googleSignInClient.signInIntent) }
        binding.tvGoToRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
        binding.tvForgotPassword.setOnClickListener { startActivity(Intent(this, ForgotPasswordActivity::class.java)) }
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString()?.trim().orEmpty()

        binding.tilEmail.error = null
        binding.tilPassword.error = null

        if (email.isEmpty()) { binding.tilEmail.error = "Email is required"; return }
        if (password.isEmpty()) { binding.tilPassword.error = "Password is required"; return }

        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.loginWithEmail(email, password)) {
                is AuthResult.Success -> {
                    if (authRepository.isCurrentUserBanned()) {
                        authRepository.logout()
                        setLoading(false)
                        toast("Your account has been suspended. Contact support for help.")
                    } else {
                        goToMain()
                    }
                }
                is AuthResult.Error -> { setLoading(false); toast(result.message) }
            }
        }
    }

    private fun signInWithGoogleCredential(credential: com.google.firebase.auth.AuthCredential) {
        setLoading(true)
        lifecycleScope.launch {
            when (val result = authRepository.loginWithGoogle(credential)) {
                is AuthResult.Success -> {
                    if (authRepository.isCurrentUserBanned()) {
                        authRepository.logout()
                        setLoading(false)
                        toast("Your account has been suspended. Contact support for help.")
                    } else {
                        goToMain()
                    }
                }
                is AuthResult.Error -> { setLoading(false); toast(result.message) }
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finishAffinity()
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !loading
        binding.btnGoogleSignIn.isEnabled = !loading
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
