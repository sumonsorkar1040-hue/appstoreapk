package com.appstore.user.ui.splash

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.appstore.user.ui.main.MainActivity
import com.appstore.user.ui.onboarding.OnboardingActivity
import com.appstore.user.utils.PrefsHelper

/** No visible UI, no delay, no network wait — just decides Onboarding vs Main
 *  from the cached local preference and hands off immediately. All the
 *  startup checks that used to gate this screen (no internet / maintenance
 *  mode / rooted device / guest sign-in) now run quietly from MainActivity
 *  once its content is already on screen, instead of blocking app open. */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val destination = if (!PrefsHelper(this).onboardingDone) OnboardingActivity::class.java else MainActivity::class.java
        startActivity(Intent(this, destination))
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0) // no fade/slide — avoids a blank frame flashing before Main/Onboarding draws
        finish()
    }
}
