package com.appstore.user.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.appstore.user.data.model.Review
import com.appstore.user.databinding.ItemReviewBinding

class ReviewAdapter : ListAdapter<Review, ReviewAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val review = getItem(position)
        holder.binding.tvUserName.text = review.userName
        holder.binding.tvComment.text = review.comment
        holder.binding.ratingBar.rating = review.rating
        Glide.with(holder.itemView.context).load(review.userPhotoUrl).into(holder.binding.ivAvatar)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Review>() {
            override fun areItemsTheSame(oldItem: Review, newItem: Review) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Review, newItem: Review) = oldItem == newItem
        }
    }
}
