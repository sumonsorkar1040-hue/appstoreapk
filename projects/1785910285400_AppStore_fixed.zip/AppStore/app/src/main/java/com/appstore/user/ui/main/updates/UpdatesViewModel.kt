package com.appstore.user.ui.main.updates

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.appstore.user.data.model.AppModel
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.utils.InstalledAppsHelper
import kotlinx.coroutines.launch

class UpdatesViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository()

    private val _updatableApps = MutableLiveData<List<AppModel>>()
    val updatableApps: LiveData<List<AppModel>> = _updatableApps

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    fun loadUpdates() {
        viewModelScope.launch {
            _isLoading.value = true
            val allApps = repository.getAllApps()
            _updatableApps.value = InstalledAppsHelper.findUpdatable(getApplication(), allApps)
            _isLoading.value = false
        }
    }
}
