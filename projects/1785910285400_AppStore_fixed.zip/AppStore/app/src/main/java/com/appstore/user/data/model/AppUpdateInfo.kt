package com.appstore.user.data.model

/**
 * Single node (not a list) describing the latest available version of the
 * App Store app itself. Populated/deleted by the admin (e.g. via the
 * Firebase console, or the Admin Panel once that phase is built) at
 * /AppUpdate. Read by "Check & Update" in Profile.
 */
data class AppUpdateInfo(
    var versionCode: Int = 0,
    var versionName: String = "",
    var iconUrl: String = "",
    var whatsNew: String = "",
    var apkUrl: String = "",
    var updatedAt: Long = 0
)
