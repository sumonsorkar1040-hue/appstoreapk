package com.appstore.user.ui.help

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.BuildConfig
import com.appstore.user.data.model.Feedback
import com.appstore.user.data.repository.AppRepository
import com.appstore.user.databinding.ActivityHelpFeedbackBinding
import kotlinx.coroutines.launch

/**
 * "Help & Feedback" screen, reachable from Profile -> Help & Feedback.
 *
 * Lets the signed-in user pick a feedback type, write a message, and send
 * it straight to the /Feedback node in Firebase for the team to review.
 */
class HelpFeedbackActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHelpFeedbackBinding
    private val repository = AppRepository()

    private val feedbackTypes = listOf("Bug Report", "Feature Request", "General Feedback", "Complaint", "Other")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelpFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        // targetSdk 35 draws content edge-to-edge by default, so the status bar
        // would otherwise overlap the top bar. Pad the root container (not the
        // top bar itself) by the top inset, so the top bar's fixed height isn't
        // squeezed and its title doesn't get clipped.
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(top = systemBars.top)
            insets
        }

        val user = FirebaseAuth.getInstance().currentUser
        binding.tvUserInfo.text = "Sending as ${user?.displayName ?: "Guest User"} · ${user?.email ?: "not signed in"}"

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, feedbackTypes)
        binding.actvType.setAdapter(adapter)
        binding.actvType.setText(feedbackTypes[0], false)
        binding.actvType.setOnClickListener { binding.actvType.showDropDown() }

        binding.ivBack.setOnClickListener { finish() }
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun submit() {
        val type = binding.actvType.text?.toString()?.trim().orEmpty()
        val message = binding.etMessage.text?.toString()?.trim().orEmpty()

        if (message.isEmpty()) {
            Toast.makeText(this, "Please write your message", Toast.LENGTH_SHORT).show()
            binding.etMessage.requestFocus()
            return
        }

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(this, "Please log in to send feedback", Toast.LENGTH_SHORT).show()
            return
        }

        setLoading(true)
        val feedback = Feedback(
            userId = user.uid,
            userName = user.displayName ?: "Anonymous",
            userEmail = user.email ?: "",
            type = type.ifEmpty { "General Feedback" },
            message = message,
            appVersion = BuildConfig.VERSION_NAME,
            timestamp = System.currentTimeMillis()
        )

        lifecycleScope.launch {
            val result = repository.submitFeedback(feedback)
            setLoading(false)
            if (result.isSuccess) {
                Toast.makeText(this@HelpFeedbackActivity, "Thanks! Your feedback was sent.", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(
                    this@HelpFeedbackActivity,
                    result.exceptionOrNull()?.message ?: "Failed to send feedback",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnSubmit.isEnabled = !loading
    }
}
