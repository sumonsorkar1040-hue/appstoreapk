package com.appstore.user.utils

object Constants {

    // ---------- Cloud Firestore collection names ----------
    // IMPORTANT: these must match the collections the Admin Panel writes to
    // (see AppStoreAdmin's FirebaseRepository) or content added in the admin
    // app will never show up here. The user app used to read these from
    // Firebase Realtime Database while the admin app wrote to Cloud
    // Firestore — two completely separate databases — which is why nothing
    // added from the admin panel ever appeared. Both apps now use Firestore.
    const val COLLECTION_APPS = "apps"
    const val COLLECTION_USERS = "users"
    const val COLLECTION_CATEGORIES = "categories"
    const val COLLECTION_BANNERS = "banners"
    const val COLLECTION_NOTIFICATIONS = "notifications"
    const val COLLECTION_REVIEWS = "reviews"
    const val COLLECTION_FEEDBACK = "feedback"
    const val COLLECTION_SEARCH_KEYWORDS = "search_keywords"
    const val COLLECTION_SETTINGS = "settings"
    const val SETTINGS_DOC_CONFIG = "config"

    // Admin-managed, unlimited custom Home-screen sections (e.g. "New Releases",
    // "Top Charts", or any other name the admin creates from the Admin Panel's
    // Categories/Sections screen). Distinct from COLLECTION_CATEGORIES (Apps/Games
    // browse-tab chips) — an app can belong to any number of these via
    // AppModel.homeSectionIds, chosen at publish time.
    const val COLLECTION_HOME_SECTIONS = "home_sections"
    const val FIELD_HOME_SECTION_IDS = "homeSectionIds"

    // Section identifiers used by AppRepository.getSection()
    const val NODE_FEATURED = "Featured"
    const val NODE_TRENDING = "Trending"
    const val NODE_TOP_CHARTS = "TopCharts"
    const val NODE_EDITOR_CHOICE = "EditorChoice"
    const val NODE_RECOMMENDED = "Recommended"
    const val NODE_NEW_RELEASES = "NewReleases"

    // Firestore field name used by the Admin Panel for the games category
    const val GAMES_CATEGORY_NAME = "Games"

    // ---------- Firebase Storage folders (used by Admin Panel for APK uploads) ----------
    const val STORAGE_APKS = "apks"

    // ---------- imgbb (used by Admin Panel to upload app icons/screenshots) ----------
    // NOTE: move this to a secure remote config / backend in production instead of hard-coding.
    const val IMGBB_API_KEY = "YOUR_IMGBB_API_KEY"
    const val IMGBB_UPLOAD_URL = "https://api.imgbb.com/1/upload"

    // ---------- GitHub (used by "Upload App" screen to host APK files) ----------
    // NOTE: move this to a secure remote config / backend in production instead of hard-coding.
    // Create a fine-grained Personal Access Token with "Contents: Read and write" on the target repo.
    const val GITHUB_TOKEN = "YOUR_GITHUB_TOKEN"
    const val GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
    const val GITHUB_REPO = "YOUR_APK_HOST_REPO"
    const val GITHUB_BRANCH = "main"
    const val GITHUB_APK_FOLDER = "apks"
    const val GITHUB_API_BASE = "https://api.github.com"

    // ---------- SharedPreferences ----------
    const val PREF_NAME = "app_store_prefs"
    const val PREF_ONBOARDING_DONE = "onboarding_done"
    const val PREF_DARK_MODE = "dark_mode"

    // ---------- Intent extras ----------
    const val EXTRA_APP_ID = "extra_app_id"
    const val EXTRA_CATEGORY = "extra_category"
    const val EXTRA_SECTION_TITLE = "extra_section_title"
    const val EXTRA_SECTION_NODE = "extra_section_node"
    const val EXTRA_QUERY = "extra_query"
    const val EXTRA_START_TAB = "extra_start_tab"
    const val EXTRA_PRESET_RATING = "extra_preset_rating"

    // ---------- Search ----------
    const val PREF_SEARCH_HISTORY = "search_history"
    const val SEARCH_HISTORY_MAX = 10

    // ---------- Categories ----------
    /** Synthetic default category tab (replaces the old "All" chip) — shows a personalized app list. */
    const val CATEGORY_FOR_YOU = "For You"
}
