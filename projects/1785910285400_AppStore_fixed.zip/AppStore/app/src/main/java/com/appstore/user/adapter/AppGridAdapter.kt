package com.appstore.user.adapter

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.appstore.user.data.model.AppModel
import com.appstore.user.databinding.ItemAppGridBinding

/**
 * Grid-view counterpart of [AppListAdapter] — same click/install callbacks, just a
 * 2-column card layout (icon on top, name/rating/Install button below) instead of a row.
 * Used for the List/Grid toggle on category browsing and admin-created Home sections.
 */
class AppGridAdapter(
    private val actionLabel: String = "Install",
    private val onClick: (AppModel) -> Unit,
    private val onActionClick: (AppModel) -> Unit
) : ListAdapter<AppModel, AppGridAdapter.GridViewHolder>(DIFF) {

    inner class GridViewHolder(val binding: ItemAppGridBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GridViewHolder {
        val binding = ItemAppGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return GridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GridViewHolder, position: Int) {
        val app = getItem(position)
        holder.binding.tvName.text = app.name
        holder.binding.tvRating.text = String.format("%.1f", app.rating)
        holder.binding.btnAction.text = actionLabel
        holder.binding.shimmerIcon.showShimmer(true)
        Glide.with(holder.itemView.context)
            .load(app.iconUrl)
            .centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade())
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerIcon.hideShimmer()
                    return false
                }
                override fun onResourceReady(resource: Drawable, model: Any, target: Target<Drawable>?, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                    holder.binding.shimmerIcon.hideShimmer()
                    return false
                }
            })
            .into(holder.binding.ivIcon)
        holder.itemView.setOnClickListener { onClick(app) }
        holder.binding.btnAction.setOnClickListener { onActionClick(app) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<AppModel>() {
            override fun areItemsTheSame(oldItem: AppModel, newItem: AppModel) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: AppModel, newItem: AppModel) = oldItem == newItem
        }
    }
}
