package com.appstore.user.ui.onboarding

import android.content.Intent
import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.auth.FirebaseAuth
import com.appstore.user.R
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.databinding.ActivityOnboardingBinding
import com.appstore.user.ui.main.MainActivity
import com.appstore.user.utils.PrefsHelper
import kotlinx.coroutines.launch

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var pages: List<OnboardingPage>
    private lateinit var dots: List<ImageView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        pages = listOf(
            OnboardingPage("Discover Thousands of Apps", "Browse a huge catalog of apps and games curated just for you.", R.drawable.ic_launcher),
            OnboardingPage("Smart Recommendations", "AI-powered suggestions based on what you like.", R.drawable.ic_launcher),
            OnboardingPage("Fast & Secure Downloads", "Download and install apps quickly and safely.", R.drawable.ic_launcher),
            OnboardingPage("Stay Up To Date", "Get notified the moment your favorite apps update.", R.drawable.ic_launcher)
        )

        binding.viewPager.adapter = OnboardingPagerAdapter(pages)
        setupDots()
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
                binding.btnNext.text = if (position == pages.lastIndex) getString(R.string.get_started) else getString(R.string.next)
            }
        })

        binding.tvSkip.setOnClickListener { finishOnboarding() }
        binding.btnNext.setOnClickListener {
            val next = binding.viewPager.currentItem + 1
            if (next < pages.size) binding.viewPager.currentItem = next else finishOnboarding()
        }
    }

    private fun setupDots() {
        dots = pages.indices.map {
            ImageView(this).apply {
                setImageResource(R.drawable.dot_indicator)
                val params = android.widget.LinearLayout.LayoutParams(8.dp(), 8.dp())
                params.marginStart = 4.dp(); params.marginEnd = 4.dp()
                layoutParams = params
                alpha = if (it == 0) 1f else 0.3f
                binding.dotsIndicator.addView(this)
            }
        }
    }

    private fun updateDots(activePosition: Int) {
        dots.forEachIndexed { index, imageView -> imageView.alpha = if (index == activePosition) 1f else 0.3f }
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun finishOnboarding() {
        PrefsHelper(this).onboardingDone = true
        if (FirebaseAuth.getInstance().currentUser != null) {
            goToMain()
        } else {
            lifecycleScope.launch {
                AuthRepository().signInAsGuest()
                goToMain()
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
