package com.appstore.user.ui.auth

import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.appstore.user.data.repository.AuthRepository
import com.appstore.user.databinding.ActivityForgotPasswordBinding
import kotlinx.coroutines.launch

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding
    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        binding.btnSendResetLink.setOnClickListener { sendResetLink() }
    }

    private fun sendResetLink() {
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        binding.tilEmail.error = null
        if (email.isEmpty()) { binding.tilEmail.error = "Email is required"; return }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnSendResetLink.isEnabled = false

        lifecycleScope.launch {
            val result = authRepository.sendPasswordReset(email)
            binding.progressBar.visibility = View.GONE
            binding.btnSendResetLink.isEnabled = true
            if (result.isSuccess) {
                Toast.makeText(this@ForgotPasswordActivity, "Reset link sent. Check your email.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this@ForgotPasswordActivity, result.exceptionOrNull()?.message ?: "Failed to send email", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
