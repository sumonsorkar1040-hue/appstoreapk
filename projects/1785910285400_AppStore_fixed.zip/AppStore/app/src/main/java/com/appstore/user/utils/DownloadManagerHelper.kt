package com.appstore.user.utils

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import java.io.File

/**
 * Wraps the system DownloadManager to fetch an APK from Firebase Storage's
 * public download URL and then launches the package installer via
 * FileProvider. Handles REQUEST_INSTALL_PACKAGES on Android 8+.
 */
class DownloadManagerHelper(private val context: Context) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val progressHandler = Handler(Looper.getMainLooper())
    private var progressPoller: Runnable? = null

    fun startDownload(apkUrl: String, appName: String, onQueued: (Long) -> Unit) {
        val fileName = "${appName.replace(" ", "_")}.apk"
        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle(appName)
            .setDescription("Downloading...")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)

        val downloadId = downloadManager.enqueue(request)
        onQueued(downloadId)
    }

    /**
     * Polls DownloadManager every [intervalMs] for real bytes-downloaded /
     * bytes-total and reports a 0-100 percent to [onProgress] so the UI can
     * animate the progress bar. Stops automatically once the download
     * leaves the RUNNING/PENDING state.
     */
    fun trackProgress(downloadId: Long, intervalMs: Long = 200L, onProgress: (Int) -> Unit) {
        stopTrackingProgress()
        val runnable = object : Runnable {
            override fun run() {
                val cursor: Cursor = downloadManager.query(DownloadManager.Query().setFilterById(downloadId))
                cursor.use {
                    if (it.moveToFirst()) {
                        val statusIdx = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                        val bytesIdx = it.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                        val totalIdx = it.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                        val status = if (statusIdx >= 0) it.getInt(statusIdx) else -1
                        val downloaded = if (bytesIdx >= 0) it.getLong(bytesIdx) else 0L
                        val total = if (totalIdx >= 0) it.getLong(totalIdx) else -1L

                        val percent = if (total > 0) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0
                        onProgress(percent)

                        if (status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING) {
                            progressHandler.postDelayed(this, intervalMs)
                        } else if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            onProgress(100)
                        }
                    }
                }
            }
        }
        progressPoller = runnable
        progressHandler.post(runnable)
    }

    fun stopTrackingProgress() {
        progressPoller?.let { progressHandler.removeCallbacks(it) }
        progressPoller = null
    }

    fun cancelDownload(downloadId: Long) {
        stopTrackingProgress()
        downloadManager.remove(downloadId)
    }

    fun registerCompletionReceiver(downloadId: Long, onComplete: (Uri?) -> Unit): BroadcastReceiver {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (id == downloadId) {
                    stopTrackingProgress()
                    val uri = downloadManager.getUriForDownloadedFile(downloadId)
                    onComplete(uri)
                    context.unregisterReceiver(this)
                }
            }
        }
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        return receiver
    }

    fun installApk(fileUri: Uri) {
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileUri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(installIntent)
    }

    /** Converts a file:// path to a FileProvider content:// Uri when needed (pre-DownloadManager Uri fallback). */
    fun getContentUriForFile(file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
