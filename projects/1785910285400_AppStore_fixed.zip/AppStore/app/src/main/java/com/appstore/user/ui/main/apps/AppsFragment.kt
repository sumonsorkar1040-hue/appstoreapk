package com.appstore.user.ui.main.apps

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.appstore.user.R
import com.appstore.user.adapter.AppGridAdapter
import com.appstore.user.adapter.AppListAdapter
import com.appstore.user.data.model.Category
import com.appstore.user.databinding.FragmentAppsBinding
import com.appstore.user.ui.detail.AppDetailActivity
import com.appstore.user.utils.Constants

class AppsFragment : Fragment() {

    private var _binding: FragmentAppsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CategoryBrowseViewModel by viewModels()
    private val args: AppsFragmentArgs by navArgs()

    private var isGridView = false

    private val listAdapter = AppListAdapter(
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> openDetail(app.id) } // Install starts from detail screen for full info
    )
    private val gridAdapter = AppGridAdapter(
        onClick = { app -> openDetail(app.id) },
        onActionClick = { app -> openDetail(app.id) }
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAppsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvApps.layoutManager = LinearLayoutManager(requireContext())
        binding.rvApps.adapter = listAdapter

        binding.ivToggleView.setOnClickListener {
            isGridView = !isGridView
            applyViewMode()
        }

        viewModel.categories.observe(viewLifecycleOwner) { populateChips(it) }
        viewModel.apps.observe(viewLifecycleOwner) {
            listAdapter.submitList(it)
            gridAdapter.submitList(it)
        }
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            if (loading) {
                binding.shimmerApps.root.visibility = View.VISIBLE
                binding.shimmerApps.root.startShimmer()
            } else {
                binding.shimmerApps.root.stopShimmer()
                binding.shimmerApps.root.visibility = View.GONE
            }
            binding.swipeRefresh.isRefreshing = false
        }

        binding.swipeRefresh.setOnRefreshListener {
            val selectedChip = binding.chipGroupCategories.findViewById<Chip>(binding.chipGroupCategories.checkedChipId)
            selectedChip?.text?.toString()?.let { viewModel.loadApps(it) }
        }

        viewModel.loadCategories(gamesOnly = false)
    }

    /** Switches the apps RecyclerView between List view and Grid view. */
    private fun applyViewMode() {
        if (isGridView) {
            binding.rvApps.layoutManager = GridLayoutManager(requireContext(), 2)
            binding.rvApps.adapter = gridAdapter
            binding.ivToggleView.setImageResource(R.drawable.ic_view_list)
        } else {
            binding.rvApps.layoutManager = LinearLayoutManager(requireContext())
            binding.rvApps.adapter = listAdapter
            binding.ivToggleView.setImageResource(R.drawable.ic_view_grid)
        }
    }

    private fun populateChips(categories: List<Category>) {
        binding.chipGroupCategories.removeAllViews()
        val preselect = args.category

        // "For You" replaces the old default "All" tab and is always first.
        val forYouChip = buildCategoryChip(Constants.CATEGORY_FOR_YOU).apply {
            isChecked = preselect == null || preselect == Constants.CATEGORY_FOR_YOU
            setOnClickListener { viewModel.loadApps(Constants.CATEGORY_FOR_YOU) }
        }
        binding.chipGroupCategories.addView(forYouChip)

        categories.forEach { category ->
            val chip = buildCategoryChip(category.name).apply {
                isChecked = preselect == category.name
                setOnClickListener { viewModel.loadApps(category.name) }
            }
            binding.chipGroupCategories.addView(chip)
        }

        val initialCategory = categories.firstOrNull { it.name == preselect }?.name ?: Constants.CATEGORY_FOR_YOU
        viewModel.loadApps(initialCategory)
    }

    /** Builds a category chip styled with the app's blue theme (filled when selected). */
    private fun buildCategoryChip(label: String): Chip = Chip(requireContext()).apply {
        text = label
        isCheckable = true
        chipBackgroundColor = ContextCompat.getColorStateList(requireContext(), R.color.chip_category_background)
        setTextColor(ContextCompat.getColorStateList(requireContext(), R.color.chip_category_text))
        chipStrokeWidth = 0f
    }

    private fun openDetail(appId: String) {
        val intent = Intent(requireContext(), AppDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_APP_ID, appId)
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
