# Firebase / Gson model classes must keep their no-arg constructors & fields for
# Realtime Database deserialization to work in release (minified) builds.
-keepclassmembers class com.appstore.user.data.model.** {
    <init>();
    <fields>;
}
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule
